using namespace std;

#include "hw6prgm.h"

int main () {

    display_header();

    intro_msg();
	
    ifstream loadFile;
    loadFile.open("stratego.txt");

    //Initializations
    typedef struct Piece piece;
    piece *game_board_pointer = new piece[BOARD_SIZE*BOARD_SIZE]; //piece game_board[BOARD_SIZE][BOARD_SIZE] as dynamic allocation
    //game_board_pointer[i][j] referred to as game_board_pointer[i*BOARD_SIZE+j]
	if (!loadFile.is_open()) {
		initialize_board(game_board_pointer);
		assign_pieces(game_board_pointer);
	}
	else if (loadFile.is_open()) {
		
		for (int j=0; j < BOARD_SIZE; j++) { //Moves left to right across board
			for (int i=0; i < 5; i++) {
				loadFile >> game_board_pointer[i*BOARD_SIZE+j].rankName >> game_board_pointer[i*BOARD_SIZE+j].color >> game_board_pointer[i*BOARD_SIZE+j].moveable;
			}
		}
		cout << "The game board has been loaded." << endl;
		
		loadFile.close();
	}
    print_board(game_board_pointer, false);
	ofstream saveFile;
	saveFile.open("stratego.txt");
    for (int j=0; j < BOARD_SIZE; j++) { //Moves left to right across board
        for (int i=0; i < 5; i++) {
			saveFile << game_board_pointer[i*BOARD_SIZE+j].rankName << endl;
			saveFile << game_board_pointer[i*BOARD_SIZE+j].color << endl;
			saveFile << game_board_pointer[i*BOARD_SIZE+j].moveable << endl;
        }
    }
	cout << "The game board has been saved." << endl;

    bool struckFlag = false, playerQuit = false;
    while ((struckFlag==false)&&(playerQuit==false)) { //Until the player strikes the flag or until the player quits,

        //Gather user entry and check whether valid
        string userEnteredCoordinate="Blank";
        bool coordinateOnBoard=false;
        bool isThatPieceMoveable=false;
        while ((playerQuit==false)&&(coordinateOnBoard==false)&&(isThatPieceMoveable==false)) {
            cout << "RED MOVE: Enter current coordinates of piece (e.g., D2, or QQ to quit): ";
            cin >> userEnteredCoordinate;
            cout << "You entered: " << userEnteredCoordinate << endl;
            if (userEnteredCoordinate=="QQ") {
                cout << "The program will now end..." << endl;
                playerQuit = true;
            }
            if ((playerQuit==false)&&(is_that_coordinate_on_the_board(userEnteredCoordinate)==true)) {
                coordinateOnBoard = true;
            }
            if ((playerQuit==false)&&(what_is_on_that_space(userEnteredCoordinate, game_board_pointer).moveable==true)) {
                isThatPieceMoveable = true;
            }
            else if (playerQuit==false) {
                cout << "Error: That piece is not movable." << endl;
                coordinateOnBoard=false;
            }
        }
        //Here, the program has a first coordinate that is on the board and movable

        string userEnteredCoordinate2="Blank";
        bool coordinateOnBoard2=false;
        bool validUpDownLeftRight=false;
        while ((playerQuit==false)&&(coordinateOnBoard2==false)&&(validUpDownLeftRight==false)) {
            cout << "RED MOVE: Enter new coordinates of piece (e.g., D2, or QQ to quit): ";
            cin >> userEnteredCoordinate2;
            cout << "You entered: " << userEnteredCoordinate2 << endl;
            if (userEnteredCoordinate2=="QQ") {
                cout << "The program will now end..." << endl;
                playerQuit = true;
            }
            if ((playerQuit==false)&&(is_that_coordinate_on_the_board(userEnteredCoordinate2)==true)) {
                coordinateOnBoard2 = true;
            }
            if ((playerQuit==false)&&(did_the_piece_moveUpDownLeftRight(userEnteredCoordinate, userEnteredCoordinate2, game_board_pointer)==true)) {
                validUpDownLeftRight = true;
            }
            else if (playerQuit==false) {
                coordinateOnBoard2=false;
            }
        }
        //Here, the program has a second coordinate that is on the board and a valid up/down/left/right from the first coordinate

        //Update board
        if ((playerQuit==false)&&(struck_flag(game_board_pointer, userEnteredCoordinate, userEnteredCoordinate2)==false)) {
            print_board(game_board_pointer, false);
			for (int j=0; j < BOARD_SIZE; j++) { //Moves left to right across board
				for (int i=0; i < 5; i++) {
					saveFile << game_board_pointer[i*BOARD_SIZE+j].rankName << endl;
					saveFile << game_board_pointer[i*BOARD_SIZE+j].color << endl;
					saveFile << game_board_pointer[i*BOARD_SIZE+j].moveable << endl;
				}
			}
			cout << "The game board has been saved." << endl;
            //Keep going with the game
        }
        else if (playerQuit==false) { //The player struck the flag
            cout << "Congratulations! You won the game!" << endl;
            print_board(game_board_pointer, true);
            struckFlag = true;
        }

    }

    if (playerQuit==true) {
        cout << "You have lost the game." << endl;
        print_board(game_board_pointer, true);
    }
    cout << "The game has now ended." << endl;
	if (saveFile.is_open()) {
		saveFile.close();
	}
    delete []game_board_pointer;

    return 0;
}

