using namespace std;

#include <iostream>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <string>
#include <fstream>

enum PieceRoles {EMPTY = 0, FLAG = 70, BOMB = 66, MARSHAL = 1, GENERAL = 2, COLONEL = 3, MAJOR = 4, CAPTAIN = 5, LIEUTENANT = 6, SERGEANT = 7, MINER = 8, SPY = 83};
enum SquareColors {NONE = 0, RED = 1, BLUE = 2};

struct Piece {
    enum PieceRoles rankName;
    enum SquareColors color;
    bool moveable;
};

const int BOARD_SIZE=5;

void display_header();
void intro_msg();

void initialize_board(Piece *game_board_pointer);
void assign_pieces(Piece *game_board_pointer);
void print_board(Piece *game_board_pointer, bool revealBoard); //Prints board with hidden or revealed enemy side

bool is_that_coordinate_on_the_board(string coordinate); //Checks whether the coordinate follows (A-E)(1-5)
Piece what_is_on_that_space(string coordinate, Piece *game_board_pointer); //Returns Piece on space of board
void reassign_space(Piece *game_board_pointer, Piece piece, string coordinates); //Changes Piece on space of board
bool did_the_piece_moveUpDownLeftRight(string oldSpace, string newSpace, Piece *game_board_pointer); //Returns true if the movement was an up/down/left/right within board bounds
bool struck_flag(Piece *game_board_pointer, string oldPieceCoor, string newPieceCoor); //Updates board and returns whether the player struck the flag
