using namespace std;

#include "hw6prgm.h"

void display_header() {
cout << "*******************************************************\n";
cout << "Computer Science and Engineering\n";
cout << "CSCE 1030 - Computer Science I\n";
cout << "Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu\n";
cout << "*******************************************************\n";
}
/* 
 ============================================================================ 
 Function    : Intro Message
 Parameters  : No parameters	 
 Return      : void has no return value
 Description : Rules about stratego game 
 ============================================================================ 
 */

void intro_msg() {
    cout << "Welcome to 1030 Stratego" << endl;
    cout << "--------------------------------------------------" << endl;
    cout << "The program will set up a 5x5 game board for a 1030 version of the game of Stratego." << endl;
    cout << "One player will compete against the computer, each assigned 10 pieces consisting of the following: " << endl;
    cout << "   1 FLAG (F)" << endl;
    cout << "   3 BOMB (B)" << endl;
    cout << "   1 MARSHAL (1) or GENERAL (2)" << endl;
    cout << "   3 COLONEL (3), MAJOR (4), CAPTAIN (5), LIEUTENANT (6), or SERGEANT (7)" << endl;
    cout << "   1 MINER (8)" << endl;
    cout << "   1 SPY (S)" << endl;
    cout << endl;
    cout << "GENERAL RULES:" << endl;
    cout << "--------------" << endl;
    cout << "For the most part, the game will follow the standard Stratego rules, although there are some exceptions." << endl;
    cout << "1. Both players (BLUE and RED) will have all of their 10 game pieces assigned randomly with the only" << endl;
    cout << "   requirement being that the FLAG must be placed in the back row. RED will start the game first." << endl;
    cout << "2. Higher ranked pieces can capture lower ranked pieces in the following order: 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> S, meaning that" << endl;
    cout << "   1 (the MARSHAL) can remove 2 (the GENERAL) and so forth. The MINER (8) piece may strike a BOMB and remove it to occupy the now unoccupied space." << endl;
    cout << "   A SPY (S), although the lowest ranked piece, may remove the MARSHAL (1) or the GENERAL (2). When pieces have equal rank, then both pieces" << endl;
    cout << "   are removed." << endl;
    cout << "3. The FLAG and BOMBs are not moveable while all of the other pieces may move one square at a time forward, backward, or sideward, but not" << endl;
    cout << "   diagonally to an open square." << endl;
    cout << "4. A player must either move or strike on his/her turn." << endl;
    cout << "5. The game ends when a player strikes his/her opponent's flag." << endl;
    cout << "--------------------------------------------------" << endl;
    cout << endl;
}
/* 
 ============================================================================ 
 Function    : Initialize board
 Parameters  : Piece *game_board_pointer  
 Return      : void has no return value
 Description : This function keeps up with the board 
 ============================================================================ 
 */
void initialize_board(Piece *game_board_pointer) {
    cout << "Initializing game board..." << endl;
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            game_board_pointer[i*BOARD_SIZE+j].rankName = EMPTY;
            game_board_pointer[i*BOARD_SIZE+j].color = NONE;
            game_board_pointer[i*BOARD_SIZE+j].moveable = false;
        }
    }
}
/* 
 ============================================================================ 
 Function    : Assign pieces
 Parameters  : Piece *game_board_pointer	 
 Return      : void has no return value
 Description : This function assigns pieces to the board 
 ============================================================================ 
 */
void assign_pieces(Piece *game_board_pointer) {
    int randomNumber, randomNumber2, randomNumber3;
    srand(time(NULL));

    cout << "Assigning BLUE pieces to board..." << endl;
    cout << "Assigning RED pieces to board..." << endl;
    //Colors for each side
    for (int j=0; j < BOARD_SIZE; j++) { //Moves left to right across board
        for (int i=0; i < 2; i++) {
            game_board_pointer[i*BOARD_SIZE+j].color = BLUE; //Makes first and second row blue
            game_board_pointer[i*BOARD_SIZE+j].moveable = false; //Makes all blue unmoveable
            game_board_pointer[(i+3)*BOARD_SIZE+j].color = RED; //Makes fourth and fifth row red
        }
    }

    //Flag for each side
    randomNumber = ((rand() % 5) + 1) - 1;
    game_board_pointer[0*BOARD_SIZE+randomNumber].rankName = FLAG; //Blue side
    //game_board_pointer[0*BOARD_SIZE+randomNumber].moveable = false;

    randomNumber = ((rand() % 5) + 1) - 1;
    game_board_pointer[4*BOARD_SIZE+randomNumber].rankName = FLAG; //Red side
    game_board_pointer[4*BOARD_SIZE+randomNumber].moveable = false;

    //Bombs for each side
    int bombCounter=0;
    while (bombCounter!=3) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = BOMB;
            //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = false;
            bombCounter++;
        }
    }
    bombCounter=0;
    while (bombCounter!=3) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = BOMB;
            game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = false;
            bombCounter++;
        }
    }

    //Marshal or general for each side
    bool marshalOrGeneralAssigned = false;
    randomNumber3 = (rand() % 2 + 1); //Marshal or general
    while (marshalOrGeneralAssigned == false) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            if (randomNumber3 == 1) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = MARSHAL;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                marshalOrGeneralAssigned = true;
            }
            else if (randomNumber3 == 2) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = GENERAL;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                marshalOrGeneralAssigned = true;
            }
        }
    }
    marshalOrGeneralAssigned = false;
    randomNumber3 = (rand() % 2 + 1); //Marshal or general
    while (marshalOrGeneralAssigned == false) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            if (randomNumber3 == 1) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = MARSHAL;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                marshalOrGeneralAssigned = true;
            }
            else if (randomNumber3 == 2) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = GENERAL;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                marshalOrGeneralAssigned = true;
            }
        }
    }

    bool minerAssigned = false;
    while (minerAssigned == false) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = MINER;
            //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
            minerAssigned = true;
        }
    }
    minerAssigned = false;
    while (minerAssigned == false) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = MINER;
            game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
            minerAssigned = true;
        }
    }

    bool spyAssigned = false;
    while (spyAssigned == false) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = SPY;
            //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
            spyAssigned = true;
        }
    }
    spyAssigned = false;
    while (spyAssigned == false) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = SPY;
            game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
            spyAssigned = true;
        }
    }

    int secondaryCounter = 0;
    while (secondaryCounter!=3) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        randomNumber3 = (rand() % 5 + 3);
        if (game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            if (randomNumber3 == 3) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = COLONEL;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 4) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = MAJOR;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 5) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = CAPTAIN;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 6) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = LIEUTENANT;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 7) {
                game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].rankName = SERGEANT;
                //game_board_pointer[(randomNumber2-1)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
        }
    }
    secondaryCounter = 0;
    while (secondaryCounter!=3) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        randomNumber3 = (rand() % 5 + 3);
        if (game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName == EMPTY) {
            if (randomNumber3 == 3) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = COLONEL;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 4) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = MAJOR;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 5) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = CAPTAIN;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 6) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = LIEUTENANT;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
            else if (randomNumber3 == 7) {
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].rankName = SERGEANT;
                game_board_pointer[(randomNumber2+2)*BOARD_SIZE+randomNumber].moveable = true;
                secondaryCounter++;
            }
        }
    }
}
/* 
 ============================================================================ 
 Function    : Print
 Parameters  : Piece *game_board_pointer, and bool revealBoard	 
 Return      : void has no return value
 Description : This function prints the board  
 ============================================================================ 
 */
void print_board(Piece *game_board_pointer, bool revealBoard) {

    //Reference Lines To Print Colors
    //Blue
    //printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName);
    //printf("\033[1;34m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName));
    //Red
    //printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName);
    //printf("\033[1;31m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName);

    cout << "    1 2 3 4 5" << endl;
    cout << "    ---------" << endl;
    for (int i = 0; i < BOARD_SIZE; i++) {
        if (i == 0) {
            cout << "A | ";
        }
        else if (i == 1) {
            cout << "B | ";
        }
        else if (i == 2) {
            cout << "C | ";
        }
        else if (i == 3) {
            cout << "D | ";
        }
        else if (i == 4) {
            cout << "E | ";
        }
        for (int j = 0; j < BOARD_SIZE; j++) {
            switch (game_board_pointer[i*BOARD_SIZE+j].rankName) {
                case 0:
                    cout << "  ";
                    break;
                case 1:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 2:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 3:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 4:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 5:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 6:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 7:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 8:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                            //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%d\033[0m", game_board_pointer[i*BOARD_SIZE+j].rankName); //Colored
                         //cout << game_board_pointer[i*BOARD_SIZE+j].rankName; //Not Colored
                         cout << " ";
                    }
                    break;
                case 66:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName)); //Colored
                            //cout << static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName); //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName)); //Colored
                         //cout << static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName); //Not Colored
                         cout << " ";
                    }
                    break;
                case 70:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName)); //Colored
                            //cout << static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName); //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName)); //Colored
                         //cout << static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName); //Not Colored
                         cout << " ";
                    }
                    break;
                case 83:
                    if (game_board_pointer[i*BOARD_SIZE+j].color==BLUE) {
                         if (revealBoard==true) {
                            printf("\033[1;34m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName)); //Colored
                            //cout << static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName); //Not Colored
                         }
                         else {
                            printf("\033[1;34mX\033[0m"); //Colored
                            //cout << "X"; //Not Colored
                         }
                         cout << " ";
                    }
                    if (game_board_pointer[i*BOARD_SIZE+j].color==RED) {
                         printf("\033[1;31m%c\033[0m", static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName)); //Colored
                         //cout << static_cast<char>(game_board_pointer[i*BOARD_SIZE+j].rankName); //Not Colored
                         cout << " ";
                    }
                    break;
            }
        }
        cout << endl;
    }
}
/* 
 ============================================================================ 
 Function    : Is that coordinate on the board
 Parameters  : String coordinate representing the position of the board.	 
 Return      : returns true or false
 Description : This function checks for the coordinates on the board 
 ============================================================================ 
 */
bool is_that_coordinate_on_the_board(string coordinate) {
    if ((coordinate[0]=='A')||(coordinate[0]=='B')||(coordinate[0]=='C')||(coordinate[0]=='D')||(coordinate[0]=='E')) {
        if ((coordinate[1]=='1')||(coordinate[1]=='2')||(coordinate[1]=='3')||(coordinate[1]=='4')||(coordinate[1]=='5')) {
            return true;
        }
        else {
            cout << "Error: Invalid column location of " << coordinate[1] << ". Try again..." << endl;
            return false;
        }
    }
    else {
        cout << "Error: Invalid row location of " << coordinate[0] << ". Try again..." << endl;
        return false;
    }
}
/* 
 ============================================================================ 
 Function    : Piece
 Parameters  : String coordinate representing the position of the board and 
		game_board_pointer position array keeps track of the pieces.	 
 Return      : returns a piece
 Description : This function prints the board  
 ============================================================================ 
 */
Piece what_is_on_that_space(string coordinate, Piece *game_board_pointer) {
    char row = coordinate[0], col = coordinate[1];
    int rowNum, colNum;
    if (row=='A') {rowNum=0;} if (row=='B') {rowNum=1;} if (row=='C') {rowNum=2;} if (row=='D') {rowNum=3;} if (row=='E') {rowNum=4;}
    if (col=='1') {colNum=0;} if (col=='2') {colNum=1;} if (col=='3') {colNum=2;} if (col=='4') {colNum=3;} if (col=='5') {colNum=4;}
    return game_board_pointer[rowNum*BOARD_SIZE+colNum];
}
/* 
 ============================================================================ 
 Function    : reassign_space
 Parameters  : Piece game board pointer, piece, and string coordinates place
		of the board 
 Return      : void has no return value
 Description : Finds that cooridinate specified and it assigns to those coordinates
		the piece to the coordinate  
 ============================================================================ 
 */
void reassign_space(Piece *game_board_pointer, Piece piece, string coordinates) {
    char row = coordinates[0], col = coordinates[1];
    int rowNum, colNum;
    if (row=='A') {rowNum=0;} if (row=='B') {rowNum=1;} if (row=='C') {rowNum=2;} if (row=='D') {rowNum=3;} if (row=='E') {rowNum=4;}
    if (col=='1') {colNum=0;} if (col=='2') {colNum=1;} if (col=='3') {colNum=2;} if (col=='4') {colNum=3;} if (col=='5') {colNum=4;}
    game_board_pointer[rowNum*BOARD_SIZE+colNum] = piece;
}
/* 
 ============================================================================ 
 Function    : did the 
 Parameters  : String oldspace, string newSpace, Piece *game_board_pointer	 
 Return      : bool returns false or true.
 Description : This functions moves the pieces. This takes old space to new
		space and checks to see if you are moving over one of your 
		pieces.
 ============================================================================ 
 */
bool did_the_piece_moveUpDownLeftRight(string oldSpace, string newSpace, Piece *game_board_pointer) {
    char oldSpaceRow = oldSpace[0]; char oldSpaceCol = oldSpace[1];
    char newSpaceRow = newSpace[0]; char newSpaceCol = newSpace[1];

    Piece oldPiecePos = what_is_on_that_space(oldSpace, game_board_pointer);
    Piece newPiecePos = what_is_on_that_space(newSpace, game_board_pointer);
    if (oldPiecePos.color == newPiecePos.color) {
        cout << "Error: Piece cannot be moved to that location. Try again..." << endl;
        return false;
    }

    bool inSameRow=false, inSameCol=false;
    if (oldSpaceRow == newSpaceRow) {
        inSameRow = true;
        if (oldSpaceCol=='1') {
            if (newSpaceCol=='2') {
                return true;
            }
        }
        if (oldSpaceCol=='2') {
            if ((newSpaceCol=='1')||(newSpaceCol=='3')) {
                return true;
            }
        }
        if (oldSpaceCol=='3') {
            if ((newSpaceCol=='2')||(newSpaceCol=='4')) {
                return true;
            }
        }
        if (oldSpaceCol=='4') {
            if ((newSpaceCol=='3')||(newSpaceCol=='5')) {
                return true;
            }
        }
        if (oldSpaceCol=='5') {
            if (newSpaceCol=='4') {
                return true;
            }
        }
    }
    if (oldSpaceCol == newSpaceCol) {
        inSameCol = true;
        if (oldSpaceRow=='A') {
            if (newSpaceRow=='B') {
                return true;
            }
        }
        if (oldSpaceRow=='B') {
            if ((newSpaceRow=='A')||(newSpaceRow=='C')) {
                return true;
            }
        }
        if (oldSpaceRow=='C') {
            if ((newSpaceRow=='B')||(newSpaceRow=='D')) {
                return true;
            }
        }
        if (oldSpaceRow=='D') {
            if ((newSpaceRow=='C')||(newSpaceRow=='E')) {
                return true;
            }
        }
        if (oldSpaceRow=='E') {
            if (newSpaceRow=='D') {
                return true;
            }
        }
    }
    if ((inSameRow==true)&&(inSameCol==true)) { //Same starting and ending point
        cout << "Error: Piece cannot be moved to that location. Try again..." << endl;
        return false;
    }
    cout << "Error: Piece cannot be moved to that location. Try again..." << endl;
    return false;
}
/* 
 ============================================================================ 
 Function    : Struck flag
 Parameters  : Piece *game_board_pointer, string oldPieceCoor, 
		string newPieceCoor	 
 Return      : Bool returns false or true
 Description : This updates the board for the move that is being made
		and if the player struck the flag then the player wins the
		game.
 ============================================================================ 
 */
bool struck_flag(Piece *game_board_pointer, string oldPieceCoor, string newPieceCoor) {
    Piece pieceAtPositionOld = what_is_on_that_space(oldPieceCoor, game_board_pointer);
    Piece pieceAtPositionNew = what_is_on_that_space(newPieceCoor, game_board_pointer);

    if (pieceAtPositionNew.color == NONE) { //Red piece is moving onto a blank space
        int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
        if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
            cout << "Moving from " << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " onto blank space at " << newPieceCoor << "..." << endl;
        }
        else {
            cout << "Moving from " << oldPieceCoor << " " << pieceCharacter << " onto blank space at " << newPieceCoor << "..." << endl;
        }
        //Make new position as old position
        pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
        pieceAtPositionNew.color = pieceAtPositionOld.color;
        pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
        reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
        //Make old position as blank
        pieceAtPositionOld.rankName = EMPTY;
        pieceAtPositionOld.color = NONE;
        pieceAtPositionOld.moveable = false;
        reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
        return false;
    }
    else if (pieceAtPositionNew.color == BLUE) { //Red piece is striking a blue piece
        if (pieceAtPositionOld.rankName == pieceAtPositionNew.rankName) { //Two pieces of same rank strike and both are removed
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "The pieces at RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " and " << newPieceCoor << " eliminated one another." << endl;
            }
            else {
                cout << "The pieces at RED@" << oldPieceCoor << " " << pieceCharacter << " and " << newPieceCoor << " eliminated one another." << endl;
            }
            //Wipe both positions
            pieceAtPositionNew.rankName = EMPTY;
            pieceAtPositionNew.color = NONE;
            pieceAtPositionNew.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if (pieceAtPositionNew.rankName==FLAG) { //Piece strikes flag and wins game
            return true;
        }
        else if ((pieceAtPositionOld.rankName!=MINER)&&(pieceAtPositionNew.rankName==BOMB)) {//Bomb destroys piece and stays in place
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " was blown up by BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " was blown up by BLUE@" << newPieceCoor << endl;
            }
            //Wipe attacking piece
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==MINER)&&(pieceAtPositionNew.rankName==BOMB)) { //Miner destroys bomb and takes space
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " has defused BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " has defused BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        // begin two spy exceptions
        else if ((pieceAtPositionOld.rankName==SPY)&&(pieceAtPositionNew.rankName==MARSHAL)) { //Spy removes marshal and takes space
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==SPY)&&(pieceAtPositionNew.rankName==GENERAL)) { //Spy removes general and takes space
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;

        }
        // end two spy exceptions
        // begin 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> S
        else if ((pieceAtPositionOld.rankName==MARSHAL)&&(pieceAtPositionNew.rankName<=SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==GENERAL)&&(pieceAtPositionNew.rankName<=SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==COLONEL)&&(pieceAtPositionNew.rankName<=SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==MAJOR)&&(pieceAtPositionNew.rankName<=SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==CAPTAIN)&&(pieceAtPositionNew.rankName<=SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==LIEUTENANT)&&(pieceAtPositionNew.rankName<=SPY&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName))) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==SERGEANT)&&(pieceAtPositionNew.rankName<=SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        else if ((pieceAtPositionOld.rankName==MINER)&&(pieceAtPositionNew.rankName==SPY)&&(pieceAtPositionOld.rankName<pieceAtPositionNew.rankName)) { //Higher rank clashes with lower rank
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " captured BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " captured BLUE@" << newPieceCoor << endl;
            }
            //Make new position as old position
            pieceAtPositionNew.rankName = pieceAtPositionOld.rankName;
            pieceAtPositionNew.color = pieceAtPositionOld.color;
            pieceAtPositionNew.moveable = pieceAtPositionOld.moveable;
            reassign_space(game_board_pointer, pieceAtPositionNew, newPieceCoor);
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
        // end 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> S
        else { //Piece strikes one of higher rank (excluding exceptions from above)
            int pieceCharacter = what_is_on_that_space(oldPieceCoor, game_board_pointer).rankName;
            if ((pieceCharacter==70)||(pieceCharacter==66)||(pieceCharacter==83)) {
                cout << "RED@" << oldPieceCoor << " " << static_cast<char>(pieceCharacter) << " was captured by BLUE@" << newPieceCoor << endl;
            }
            else {
                cout << "RED@" << oldPieceCoor << " " << pieceCharacter << " was captured by BLUE@" << newPieceCoor << endl;
            }
            //Make old position as blank
            pieceAtPositionOld.rankName = EMPTY;
            pieceAtPositionOld.color = NONE;
            pieceAtPositionOld.moveable = false;
            reassign_space(game_board_pointer, pieceAtPositionOld, oldPieceCoor);
            return false;
        }
    }
}
