#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
cout << "*******************************************************\n";
cout << "Computer Science and Engineering\n";
cout << "CSCE 1030 - Computer Science I\n";
cout << "Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu\n";
cout << "*******************************************************\n";

	/*
	Si number of susceptible today 
	Sj number of susceptible yesterday
	Ii infectious people today
	Ij infectious people yesterday
	Ri recovered people today
	Rj recovered people yesterday
	B is the contact rate the rate at which people come in contact
	  with infectious people and get infected
	y is the recovery rate the rate at which people recover from the disease
	j=i-1
	 */
	double B, y;
	int Sj, Ij, Rj, Si, Ii, Ri, Dayi, Dayj; 
	Rj=0;
	Dayj=1;
	printf("Please enter a positive, whole number for the total of the population you to simulate: ");
	scanf("%i",&Sj);
	if(0 > Sj)
	{
	printf("%i is not a postive whole number. Please enter a positive whole number for population:",Sj);	
	}
	printf("Please enter a positive, whole number that is less than the total population for the number of infectious individuals: ");
	scanf("%i",&Ij);
	if(Ij > Sj)
	{
	printf("%i is not a positive whole number or is greater than the total population of %i. Please enter a postive whole number for the number of infected individuals:",Ij,Sj);
	}
	printf("Please enter a positive number greater than 0 and less than 1 for the contact rate: ");
	scanf("%lf",&B);
	if(B<0 && B>1)
	{
	printf("%lf is not greater than 0 and less than 1. Please enter a positive number greater than 0 and less than 1 for the contact rate:",B);
	}	
	printf("Please enter a positive number greater than 0 and less than 1 for the recovery rate: ");
	scanf("%lf",&y);
	if(y<0 && y>1)
	{
	printf("%lf is not greater than 0 and less than 1. Please enter a postive number greater than 0 and less than 1 for the contact rate:",y);
	}
	//Do While loop
	do {
	//scanf("%lf%lf%lf%lf",&Day,&S,&I,&R);
	printf("Day %i S: %i I: %i R: %i\n",Dayi,Sj,Ij,Rj);	
	//scanf("%i",&Dayj);
	Dayi = Dayj++;
	Si = Sj-B*Ij*Sj;
	Ii = Ij+B*Ij*Sj-y*Ij;
	Ri = Rj+y*Ij;
	Sj = Si;
	Ij = Ii;
	Rj = Ri;
	} while (Ii>0);
	Dayi=Dayi-1;
	printf("The outbreak took %i days to end\n",Dayi);
	scanf("%i",&Dayi);

	return 0;  
}
