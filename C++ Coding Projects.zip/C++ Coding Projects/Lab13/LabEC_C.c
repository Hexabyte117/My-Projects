// Author: Elijah Goodrich elijahgoodrich@my.unt.edus
// Date: 12/7/17
// Intructor: Helsing
// Description: This program uses dynamic memory allocation to sort a list of titles from an input file

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUMBOOKS 12

int main() {
    FILE *infile;
    char inFileName[17];

    //Initialize library, the pointer to an array of char pointers
    char** library = malloc(sizeof(char*)*NUMBOOKS);

    printf("Enter the name of the file to read from: ");
    scanf("%s", inFileName);

    infile = fopen(inFileName, "r");
    if (infile == NULL) {
        printf("Unable to read from file %s\n", inFileName);
        exit(EXIT_FAILURE);
    }

    char temp[30];
    int arrPos = 0;

    //Read in one line at a time until EOF and store each title
    //in the next available slot in library
    while(fgets(library,30,infile)!=EOF) {
        puts(library);
    }

    char *swap;
    int i, j, min;

    for(i=0; i<NUMBOOKS; i++) {
        min=i;
        for (j=i+1; j<NUMBOOKS; j++) {
            //Compare the two book titles and set min appropriately
        }

        //Swap the book titles positions using the swap char*
    }

    for (arrPos=0; arrPos<NUMBOOKS; arrPos++) {
        printf("Book %d: %s", (arrPos+1), library[arrPos]);
    }

    fclose(infile);

    return 0;
}
