// Author: Elijah Goodrich elijahgoodrich@my.unt.edus
// Date: 12/7/17
// Intructor: Helsing
// Description: This program uses dynamic memory allocation to open a file and convert values to pounds

#include <stdio.h>
#include <stdlib.h>

#define KG_TO_POUNDS 2.2042

int main () {

    FILE *file_pointer;
    file_pointer = fopen("kilograms.txt", "r");
    if (fopen==NULL) {
        printf("The file could not be opened.");
        exit(1);
    }

    char convertedFileName[20];
    printf("Enter the name of the file to store converted values in: ");
    scanf("%s",convertedFileName);
    FILE *file_pointer_2;
    file_pointer_2 = fopen(convertedFileName, "w");
    if (file_pointer_2==NULL) {
        printf("The file could not be opened.");
        exit(1);
    }

    double convertedValue;
    while(fscanf(file_pointer,"%lf",&convertedValue)!=EOF) {
        convertedValue = KG_TO_POUNDS*convertedValue;
        fprintf(file_pointer_2,"%lf ",convertedValue);
    }

    fclose(file_pointer);
    fclose(file_pointer_2);

    return 0;
}
