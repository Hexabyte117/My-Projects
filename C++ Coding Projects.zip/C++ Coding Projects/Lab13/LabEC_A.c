// Author: Elijah Goodrich elijahgoodrich@my.unt.edus
// Date: 12/7/17
// Intructor: Helsing
// Description: This program uses dynamic memory allocation to store flips of a coin

#include <stdio.h>
#include <stdlib.h>

int main () {
    //Malloc and calloc to allocate memory
    //Use free to deallocate

    srand(time(NULL));

    char *coin_tosses;
    coin_tosses = (char*)malloc(sizeof(char));
    //To set, use coin_tosses[index] = 'a';

    int coin;
    char result;
    char want_to_continue='0';
    int count = 0;
    int headCount = 0;
    int tailCount = 0;
    while (want_to_continue!='q') {
        if (want_to_continue!='0') {
            coin = (rand() % 2) + 1;
            if (coin==1) {
                result = 'H';
                headCount++;
                coin_tosses[count]=result;
                printf("The result of the coin toss was: Heads\n");
                count++;
                realloc(coin_tosses, sizeof(char)*(count+1));
            }
            else if (coin==2) {
                result = 'T';
                tailCount++;
                coin_tosses[count]=result;
                printf("The result of the coin toss was: Tails\n");
                count++;
                realloc(coin_tosses, sizeof(char)*(count+1));
            }
        }
        printf("Do you want to perform a coin toss? Enter 'q' to quit or any other key to continue: ");
        scanf(" %c", &want_to_continue);
    }
    int i;
    for(i=0; i<count; i++) {
        printf("%c ", coin_tosses[i]);
    }
    printf("\n%d rolls were completed.\n", count);
    printf("%d rolls were heads.\n", headCount);
    printf("%d rolls were tails.\n", tailCount);

    free(coin_tosses);

    return 0;
}
