/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/19/17
	Intructor: Helsing
	Description: Void function 
*/
#include <iostream>
#include <cmath>
using namespace std;

void instructions(double n, int k, int j);

int main()
{
	double n, ans;
	int j,k;
	cout<<"Enter a positive integer: ";
	cin>>n;
	cout<<"What power would you like this number be raised to?: ";
	cin>>k;
	cout<<"What precision would you like (enter value range of 1-8): ";
	cin>>j;
	instructions(n,k,j);

	return 0;
}	
void instructions(double n, int k, int j)
{
	double answer;
	answer=pow(n,k);
	cout.setf(ios::fixed);
        cout.setf(ios::showpoint);
        cout.precision(j);
        cout<<"The power of "<<n<<" raised to "<<k<<" is equal to "<<answer<<endl;

}
