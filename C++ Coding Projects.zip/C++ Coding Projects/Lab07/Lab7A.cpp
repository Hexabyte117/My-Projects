/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/19/17
	Intructor: Helsing
	Description: Functions scope of variable
*/
#include <iostream>
#include <cmath>
using namespace std;

const double PI = 3.14159; // This constant is defined globally

//function prototypes
double base_area(double r);
double side_area(double r, double h);
double total_surfacearea(double base, double side);

int main()
{
	double h, r; // height and radius variables local to main
	double base, side, total; // base area and side area variables local to main

	cout << "Enter radius and height of the cone in cm: ";
	cin >> r >> h;
	cout << endl;
	cout << "You have entered r = " << r << " and h = " << h <<"." << endl;
	cout << "Using inches, so converting r and h tp inches." << endl;

	base = base_area(r);
	cout << "Base surface area of cone: " << base << " square inches." << endl;
	side = side_area(r,h);
	cout << "Side surface area of cone: " << side << " square inches." << endl;
	total = total_surfacearea(base,side);
	cout << "Total surface area of cone: " << total << endl;

	return 0;
}
double base_area(double r)
{
	//Base area is the area of the base of the cone
	r = r*0.3937; //conveting r to inches
	return PI*pow(r,2);
}	

double side_area(double r, double h)
{
	double area; //variable local to side_area function
	r = r*0.3937; //conveting r to inches
	h = h*0.3937; //conveting h to inches
	area = PI*r*h;
	return area;
}

double total_surfacearea(double base, double side)
{
	double surfacearea; // variable local to the total_surface area function
	surfacearea = base + side;
	return surfacearea;	
}	
