/*       Author: Elijah Goodrich elijahgoodrich@my.unt.edu        Date: 10/19/17        Intructor: Helsing        Description: IOstream*/
#include <iostream>
#include <fstream>
using namespace std;
int main()
{
	int num;
	int total=1;
	ifstream in_stream;
	in_stream.open("Lab7D.txt");
	while(in_stream >> num)
	{total=total*num;}
	cout<<"Result is: "<<total<<endl;in_stream.close();
return 0;}