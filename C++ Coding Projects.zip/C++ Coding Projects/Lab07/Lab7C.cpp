/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/19/17
	Intructor: Helsing
	Description: Call by reference 
*/
#include <iostream>
using namespace std;

// Declaration of function that reads the values for i and j
void get_input(int& i, int& j);
int process(int i, int j);

int main()
{
	int i, j;
	get_input(i,j);
	//call process to multiply 1 by 30 and subtrat i from j
	process(i,j);
	cout<<"Just returned from fuction process: i= "<<i<<" j= "<<j<<endl;
	return 0;
}
void get_input(int& i, int& j)
{
	cout<<"Enter two values for i and j seperated by a single space, then press <Enter>: ";
	cin>>i>>j;
	cout<<endl;
	return; //a void function returns nothing
}
int process(int i, int j)
{
        
	i=i*30;
	j=j-i;
	       
        
}
