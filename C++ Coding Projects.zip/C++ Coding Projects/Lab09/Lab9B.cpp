/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/02/17
	Intructor: Helsing
	Description: spooky time lower and upper case
*/
#include <iostream>
#include <cctype>
using namespace std;

int main()
{
	char c;
	
	cout << "Enter a character \n";
	cin >> c;
	
	if(isalpha(c))
	{//check to see if it is a letter of alphabet
		if ( isupper(c) ) //check to see if it is uppercase
		{	
			cout << "Your character " << c << " is uppercase, " << endl;
			c = tolower(c);
			cout << "and the ghost changed it into a lower case case " << c <<"."<<endl;
		}
		else
		{	cout << "Your character " << c << " is in lowercase, " << endl;
			c = toupper(c);
			cout << "and the ghost changed it into an uppercase " << c << " is." << endl;
		}
	}
	 else if (isdigit(c))
                {
                       cout << "Your character " << c << " is a digit " << endl;
                }
         else if (isspace(c))
               {
                       cout << "Your ghost has found a space " << endl;
                       
               }

	else
	{
	cout << "The ghost cannot determine what type of character " << c << " is." <<endl;
	}

	return 0;
}
