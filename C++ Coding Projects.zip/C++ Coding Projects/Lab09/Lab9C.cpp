/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/02/17
	Intructor: Helsing
	Description: spooky time with arrays
*/

#include <iostream>

using namespace std;
const int SIZE = 8;

int main()
{
int TotalZombies=0, i, hordeList[SIZE]; //declare int array that can store 8 values
for (i=0; i < SIZE; i++ )
	{	
		cout << "Enter the number of zombies in horde " << i+1 << ": ";
		cin >> hordeList[i];	
	}
for(int i=SIZE; i > 0; i--)
{
	cout << "Horde #" << i << ": " << hordeList[i-1]<<endl;
	TotalZombies += hordeList[i-1];
}
cout << "\n The total number of zombies is " << TotalZombies << "\n I hope you're ready !\n";
return 0;
}
