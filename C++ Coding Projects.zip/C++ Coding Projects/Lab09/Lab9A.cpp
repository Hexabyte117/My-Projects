/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/02/17
	Intructor: Helsing
	Description: spooky time
*/

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <cctype>
using namespace std;

void get_stream(ifstream& in_s, ofstream& out_s);

int main()
{
	char c;
	string spook, temp;
	int number;
	ifstream in_s; 	// declaration of the stream of type input
	ofstream out_s; // declaration of the stream of type output
	
	get_stream(in_s, out_s);
	
	cout << "I am reading and writing the contents of the file \n";
	in_s.get(c); 
	while (!in_s.eof()) // read all characters one-by-one to ed of the file
	{
		if(isalpha(c))
		{
			in_s.putback(c);
			in_s >> temp;
			spook += temp;
			spook += " ";
		}
		else if(isdigit(c))
		{
			in_s.putback(c);
			in_s >> number;
		}
		else if(c == '\n')
		{
			out_s << spook << " " << number << endl;
			spook = "";
		}
		in_s.get(c);
	}
	
	cout << "\nI a done with writing the contents of the file \n";

	in_s.close(); //close the file
	out_s.close(); //close the file
	
	return 0;
}

void get_stream(ifstream& in_s, ofstream& out_s)
{
	char input_file[15];
	cout << "Please input the input file name \n"; // get the file name
	cin >> input_file;
	
	in_s.open(input_file); // connect to the input file and test
	if(in_s.fail())
	{
		cout << "Input file opening failed. \n";
		exit(EXIT_FAILURE); // exit if cannot open file
	}
	
	char output_file[15];
	cout << "Please input the output file name \n"; // get the file name
	cin >> output_file;
	
	out_s.open(output_file); // connect to the output file and test 
	if (out_s.fail())
	{
		cout << "Output file opening failed. \n";
		exit(EXIT_FAILURE); // exit if cannot open file
	}
}
