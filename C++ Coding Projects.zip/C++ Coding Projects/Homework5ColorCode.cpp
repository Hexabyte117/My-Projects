#include <stdio.h>
#include <iostream>

using namespace std;

int main () {
	printf("Test\n");
	int character = 66;
	printf("\033[1;34m%c\033[0m\n", static_cast<char>(character));
	 printf("\033[1;31m%c\033[0m\n", static_cast<char>(character));
	return 0;
}
