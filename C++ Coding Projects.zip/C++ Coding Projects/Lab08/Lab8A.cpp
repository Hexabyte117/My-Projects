/* Author:      Elijah Goodrich (Elijah.Goodrich@my.unt.edu)   
Date:   	10/26/17
Instructor:   	Helsing
Description: 	Functions calling ot er functions
*/

#include <iostream>
#include <cmath>
using namespace std;

//function prototypes
double base_area(); //Area of rectangle
double pyramid_volume(); //Volume

int main()
{
	
	cout << "The volume of the Rectagular Pyramid:" << pyramid_volume() << endl;

	return 0;
}

double base_area()
{
 	double l, w, b; // l is length and w is width
        cout << "Enter the Length, and Width of your Rectangular Pyramid:";
        cin >> l >> w; 
        cout << endl;
	b = l*w;

	return b;	
}

double pyramid_volume()
{
	double h, volume, base;
	base = base_area();
	cout << "Enter the Height of your Pyramid:";
	cin >> h;
	volume =(1.0/3.0)*base*h;

	return volume;

}
