/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/26/17
	Intructor: Helsing
	Description: get function
*/
#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

void get_stream(ifstream& in_s, ofstream& out_s);

int main()
{
	char c;
	ifstream in_s; // declaration of the stream of type input
	ofstream out_s; //declaration of the stream of type output
	
	get_stream(in_s, out_s);
	cout << "here are the entire conents of the input file \n";
	in_s>>c;
	while (c!='$') // read al characters one-by-one untile you reach '$'
	{
	out_s<<c;
	in_s>>c;
	}
	cout << "\nI am done with writing the contents of the file \n";
	in_s.close(); //close the file
	out_s.close(); //close the file
	
	return 0;
}
void get_stream(ifstream& in_s, ofstream& out_s)
{
	char input_file[15];
	cout << "Please input the input file name \n"; //get file name
	cin >> input_file;
	
	in_s.open(input_file); //connect to the input file and test
	if(in_s.fail())
	{
		cout << "Input file opening failed. \n";
		exit(EXIT_FAILURE); /exit if cannot open file
		
	}
	char output_file[15];
	cout << "Please input the output file name \n"; //get file name
	cin >> output_file;
	
	out_s.open(output_file); // connect to the output and test
	if (out_s.fail())
	{
		cout << "Output file opening failed. \n";
		exit(EXIT_FAILURE); //exit if connot open
	}
}
