/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/19/17
	Intructor: Helsing
	Description: Iostream
*/
#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main()
{
	double num;
	double largest=0.0;
	ifstream in_stream;
	ofstream out_stream;

	in_stream.open("numbers.dat");
	out_stream.open("largest.dat");
	
	while(in_stream >> num)
	{
	if(num>largest){
	largest=num;
	exit(EXIT_FAILURE);
	}
	}
 	//out_stream.open("largest.dat");	
	out_stream<<largest;

	in_stream.close();
	out_stream.close();

	return 0;
}

