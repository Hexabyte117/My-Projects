/* Author:      Elijah Goodrich (Elijah.Goodrich@my.unt.edu)   
Date:   	10/26/17
Instructor:   	Helsing
Description: 	Debugging
*/

#include <iostream>
using namespace std;

int main()
{
	int i, num, j=1;
	cout << "Enter the number: ";
	cin >> num;
	for (i=1; i <= num; i++)
	{
		j = j * i;
	}
	cout << "Factorial of " << num <<" is "<< j <<"."<<endl;

	return 0;
}
