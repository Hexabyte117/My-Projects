/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 9/28/17
	Intructor: Helsing
	Description: Using loops for n! 
*/
#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{

int ni=1;
int nj=1;
int ans; 

printf("Enter a non-negative integer: ");
scanf("%i",&ans);
if(ni<0)
	{
	printf("The number you have entered was invalid. Please enter a non-nonegative integer:\n ");
	}

	while(ni<=ans)
	{
	nj = nj * ni;	
	ni++;
	}
	ni=ni-1;
	printf("%i! is the factorial of %i \n",ni,nj);
return 0;
}

