/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 9/28/17
	Intructor: Helsing
	Description: Working with enumeration types
*/
#include <iostream>
using namespace std;

int main()
{
	int firstOperand, secondOperand;
	int operation;
	cout<< "Enter the first number: ";
	cin>>firstOperand;
	cout<<"Enter the second: ";
	cin>>secondOperand;
	cout<<"Enter the operation to be performed (1=ADD, 2=SUBSTRACT, 3=MULTIPLY,4=DIVIDE):";
	cin>>operation;
	if (operation==1){
		cout<<"The result of adding "<<firstOperand<<" with "<<secondOperand<<" is: "<< firstOperand+secondOperand<<endl;
}
	else if(operation==2){
	cout<<"The result of subtracting "<<secondOperand<<" from "<<firstOperand<<" is: "<<firstOperand-secondOperand<<endl;
	}
	else if(operation==3){
        cout<<"The result of multiplying "<<firstOperand<<" with "<<secondOperand<<" is: "<<firstOperand*secondOperand<<endl;
	}
	else if(operation==4){
        cout<<"The result of dividing "<<firstOperand<<" with "<<secondOperand<<" is: "<<firstOperand/secondOperand<<endl;
	}
	return 0;
}
