/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 9/28/17
	Intructor: Helsing
	Description: Working with loops
*/
#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
	int month=0;
	do {
	printf("Please enter a number between 1 and 12 to specify the month:");
	scanf("%i",&month);
   	} while (month<1 || month>12);
	printf("Thanks. you entered %i\n",month);
	return 0;
}
