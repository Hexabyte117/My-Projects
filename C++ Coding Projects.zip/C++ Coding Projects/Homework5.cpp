/*
*******************************************************
Computer Science and Engineering
CSCE 1030 - Computer Science I
Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu
*******************************************************
*/
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <stdio.h>

using namespace std;

void display_header();
void intro_msg();
void initialize_board(int SIZE, int positionsArray[5][5], int colorsArray[5][5]);
void assign_pieces(int SIZE, int positionsArray[5][5], int colorsArray[5][5]);
void print_board(int SIZE, int positionsArray[5][5], int colorsArray[5][5]);

enum PieceRoles {EMPTY = 0, FLAG = 70, BOMB = 66, MARSHAL = 1, GENERAL = 2, COLONEL = 3, MAJOR = 4, CAPTAIN = 5, LIEUTENANT = 6, SERGEANT = 7, MINER = 8, SPY = 83};
enum SquareColors {NONE = 0, RED = 1, BLUE = 2};

int main () {
    const int BOARD_SIZE=5;

    /*
    //Testing
    PieceRoles testVar;
    testVar = EMPTY;
    cout << testVar << endl;
    */

    display_header();

    intro_msg();

    int game_board_positions[BOARD_SIZE][BOARD_SIZE];
    int game_board_colors[BOARD_SIZE][BOARD_SIZE];

    initialize_board(BOARD_SIZE, game_board_positions, game_board_colors);
    assign_pieces(BOARD_SIZE, game_board_positions, game_board_colors);
    print_board(BOARD_SIZE, game_board_positions, game_board_colors);

    return 0;
}

void display_header() {
cout << "*******************************************************\n";
cout << "Computer Science and Engineering\n";
cout << "CSCE 1030 - Computer Science I\n";
cout << "Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu\n";
cout << "*******************************************************\n";
}
/* 
 ============================================================================ 
 Function    : Intro Message
 Parameters  : No parameters	 
 Return      : void has no return value
 Description : Rules about stratego game 
 ============================================================================ 
 */

void intro_msg() {
    cout << "Welcome to 1030 Stratego" << endl;
    cout << "--------------------------------------------------" << endl;
    cout << "The program will set up a 5x5 game board for a 1030 version of the game of Stratego." << endl;
    cout << "One player will compete against the computer, each assigned 10 pieces consisting of the following: " << endl;
    cout << "   1 FLAG (F)" << endl;
    cout << "   3 BOMB (B)" << endl;
    cout << "   1 MARSHAL (1) or GENERAL (2)" << endl;
    cout << "   3 COLONEL (3), MAJOR (4), CAPTAIN (5), LIEUTENANT (6), or SERGEANT (7)" << endl;
    cout << "   1 MINER (8)" << endl;
    cout << "   1 SPY (S)" << endl;
    cout << endl;
    cout << "GENERAL RULES:" << endl;
    cout << "--------------" << endl;
    cout << "For the most part, the game will follow the standard Stratego rules, although there are some exceptions." << endl;
    cout << "1. Both players (BLUE and RED) will have all of their 10 game pieces assigned randomly with the only" << endl;
    cout << "   requirement being that the FLAG must be placed in the back row. RED will start the game first." << endl;
    cout << "2. Higher ranked pieces can capture lower ranked pieces in the following order: 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> S, meaning that" << endl;
    cout << "   1 (the MARSHAL) can remove 2 (the GENERAL) and so forth. The MINER (8) piece may strike a BOMB and remove it to occupy the now unoccupied space." << endl;
    cout << "   A SPY (S), although the lowest ranked piece, may remove the MARSHAL (1) or the GENERAL (2)." << endl;
    cout << "3. The FLAG and BOMBs are not moveable while all of the other pieces may move one square at a time forward, backward, or sideward, but not" << endl;
    cout << "   diagonally to an open square." << endl;
    cout << "4. A player must either move or strike on his/her turn." << endl;
    cout << "5. The game ends when a player strikes his/her opponent's flag." << endl;
    cout << "--------------------------------------------------" << endl;
    cout << endl;
}
/* 
 ============================================================================ 
 Function    : Initialize board
 Parameters  : Size int representing the size of the board and int position
                array keeps track of the pieces.  
 Return      : void has no return value
 Description : This function keeps up with the board 
 ============================================================================ 
 */

void initialize_board(int SIZE, int positionsArray[5][5], int colorsArray[5][5]) {
    PieceRoles noRole = EMPTY;
    SquareColors noColor = NONE;
    cout << "Initializing game board..." << endl;
    for (int i =0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            positionsArray[i][j]=noRole;
            colorsArray[i][j]=noColor;
        }
    }
}
/* 
 ============================================================================ 
 Function    : Assign pieces
 Parameters  : Size int representing the size of the board and int position
                array keeps track of the pieces.	 
 Return      : void has no return value
 Description : This function assigns pieces to the board 
 ============================================================================ 
 */

void assign_pieces(int SIZE, int positionsArray[5][5], int colorsArray[5][5]) {
    int randomNumber, randomNumber2, randomNumber3;
    srand(time(NULL));

    SquareColors blue = BLUE;
    SquareColors red = RED;
    cout << "Assigning BLUE pieces to board..." << endl;
    cout << "Assigning RED pieces to board..." << endl;
    //Colors for each side
    for (int j=0; j < SIZE; j++) { //Moves left to right across board
        for (int i=0; i < 2; i++) {
            colorsArray[i][j] = blue; //Makes first and second row blue
            colorsArray[i+3][j] = red; //Makes fourth and fifth row red
        }
    }

    //Flag for each side
    PieceRoles flag = FLAG;
    randomNumber = ((rand() % 5) + 1) - 1;
    positionsArray[0][randomNumber] = flag; //Blue side
    randomNumber = ((rand() % 5) + 1) - 1;
    positionsArray[4][randomNumber] = flag; //Red side

    //Bombs for each side
    PieceRoles bomb = BOMB;
    int bombCounter=0;
    while (bombCounter!=3) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2-1][randomNumber] == 0) {
            positionsArray[randomNumber2-1][randomNumber] = bomb;
            bombCounter++;
        }
    }
    bombCounter=0;
    while (bombCounter!=3) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2+2][randomNumber] == 0) {
            positionsArray[randomNumber2+2][randomNumber] = bomb;
            bombCounter++;
        }
    }

    //Marshal or general for each side
    PieceRoles marshal = MARSHAL;
    PieceRoles general = GENERAL;
    bool marshalOrGeneralAssigned = false;
    randomNumber3 = (rand() % 2 + 1); //Marshal or general
    while (marshalOrGeneralAssigned == false) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2-1][randomNumber] == 0) {
            if (randomNumber3 == 1) {
                positionsArray[randomNumber2-1][randomNumber] = marshal;
                marshalOrGeneralAssigned = true;
            }
            else if (randomNumber3 == 2) {
                positionsArray[randomNumber2-1][randomNumber] = general;
                marshalOrGeneralAssigned = true;
            }
        }
    }
    marshalOrGeneralAssigned = false;
    randomNumber3 = (rand() % 2 + 1); //Marshal or general
    while (marshalOrGeneralAssigned == false) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2+2][randomNumber] == 0) {
            if (randomNumber3 == 1) {
                positionsArray[randomNumber2+2][randomNumber] = marshal;
                marshalOrGeneralAssigned = true;
            }
            else if (randomNumber3 == 2) {
                positionsArray[randomNumber2+2][randomNumber] = general;
                marshalOrGeneralAssigned = true;
            }
        }
    }

    PieceRoles miner = MINER;
    bool minerAssigned = false;
    while (minerAssigned == false) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2-1][randomNumber] == 0) {
            positionsArray[randomNumber2-1][randomNumber] = miner;
            minerAssigned = true;
        }
    }
    minerAssigned = false;
    while (minerAssigned == false) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2+2][randomNumber] == 0) {
            positionsArray[randomNumber2+2][randomNumber] = miner;
            minerAssigned = true;
        }
    }

    PieceRoles spy = SPY;
    bool spyAssigned = false;
    while (spyAssigned == false) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2-1][randomNumber] == 0) {
            positionsArray[randomNumber2-1][randomNumber] = spy;
            spyAssigned = true;
        }
    }
    spyAssigned = false;
    while (spyAssigned == false) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        if (positionsArray[randomNumber2+2][randomNumber] == 0) {
            positionsArray[randomNumber2+2][randomNumber] = spy;
            spyAssigned = true;
        }
    }

    PieceRoles colonel = COLONEL; //3
    PieceRoles major = MAJOR; //4
    PieceRoles captain = CAPTAIN; //5
    PieceRoles lieutenant = LIEUTENANT; //6
    PieceRoles sergeant = SERGEANT; //7
    int secondaryCounter = 0;
    while (secondaryCounter!=3) { //Blue side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        randomNumber3 = (rand() % 5 + 3);
        if (positionsArray[randomNumber2-1][randomNumber] == 0) {
            if (randomNumber3 == 3) {
                positionsArray[randomNumber2-1][randomNumber] = colonel;
                secondaryCounter++;
            }
            else if (randomNumber3 == 4) {
                positionsArray[randomNumber2-1][randomNumber] = major;
                secondaryCounter++;
            }
            else if (randomNumber3 == 5) {
                positionsArray[randomNumber2-1][randomNumber] = captain;
                secondaryCounter++;
            }
            else if (randomNumber3 == 6) {
                positionsArray[randomNumber2-1][randomNumber] = lieutenant;
                secondaryCounter++;
            }
            else if (randomNumber3 == 7) {
                positionsArray[randomNumber2-1][randomNumber] = sergeant;
                secondaryCounter++;
            }
        }
    }
    secondaryCounter = 0;
    while (secondaryCounter!=3) { //Red side
        randomNumber = ((rand() % 5) + 1) - 1;
        randomNumber2 = (rand() % 2 + 1);
        randomNumber3 = (rand() % 5 + 3);
        if (positionsArray[randomNumber2+2][randomNumber] == 0) {
            if (randomNumber3 == 3) {
                positionsArray[randomNumber2+2][randomNumber] = colonel;
                secondaryCounter++;
            }
            else if (randomNumber3 == 4) {
                positionsArray[randomNumber2+2][randomNumber] = major;
                secondaryCounter++;
            }
            else if (randomNumber3 == 5) {
                positionsArray[randomNumber2+2][randomNumber] = captain;
                secondaryCounter++;
            }
            else if (randomNumber3 == 6) {
                positionsArray[randomNumber2+2][randomNumber] = lieutenant;
                secondaryCounter++;
            }
            else if (randomNumber3 == 7) {
                positionsArray[randomNumber2+2][randomNumber] = sergeant;
                secondaryCounter++;
            }
        }
    }
}
/* 
 ============================================================================ 
 Function    : Print
 Parameters  : Size int representing the size of the board and int position
                array keeps track of the pieces.	 
 Return      : void has no return value
 Description : This function prints the board  
 ============================================================================ 
 */

void print_board(int SIZE, int positionsArray[5][5], int colorsArray[5][5]) {
    SquareColors blue = BLUE;
    SquareColors red = RED;
    cout << "    1 2 3 4 5" << endl;
    cout << "    ---------" << endl;
    for (int i = 0; i < SIZE; i++) {
        if (i == 0) {
            cout << "A | ";
        }
        else if (i == 1) {
            cout << "B | ";
        }
        else if (i == 2) {
            cout << "C | ";
        }
        else if (i == 3) {
            cout << "D | ";
        }
        else if (i == 4) {
            cout << "E | ";
        }
        for (int j = 0; j < SIZE; j++) {
            switch (positionsArray[i][j]) {
                case 0:
                    cout << "  ";
                    break;
                case 1:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 2:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 3:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 4:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 5:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 6:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 7:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 8:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%d\033[0m", (positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 66:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%c\033[0m", static_cast<char>(positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%c\033[0m", static_cast<char>(positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 70:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%c\033[0m", static_cast<char>(positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%c\033[0m", static_cast<char>(positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
                case 83:
		    if (colorsArray[i][j]==blue) {
		         printf("\033[1;34m%c\033[0m", static_cast<char>(positionsArray[i][j]));
			 cout << " ";
		    }
		    if (colorsArray[i][j]==red) {
		         printf("\033[1;31m%c\033[0m", static_cast<char>(positionsArray[i][j]));
			 cout << " ";
		    }
                    break;
            }
        }
        cout << endl;
    }
}

