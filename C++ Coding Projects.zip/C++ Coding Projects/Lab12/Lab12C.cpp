/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edus
	Date: 11/30/17
	Intructor: Helsing
	Description: 2D arrays 
*/
#include <iostream>
using namespace std;


struct Student{
		Student s1;
		s1.firstname="John";
		s1.lastname="Hudson";
		s1.quizgrade=25;
		s1.examgrade=25;
		s1.assignmentgrade=50;
		cout<<"First name:";
		cout<<s1.firstname<<endl;
		cout<<"Last name:";
        	cout<<s1.lastname<<endl;
		cout<<"Quiz grade:";
		cout<<s1.quizgrade<<endl;
		cout<<"Exam grade:";
		cout<<s1examgrade<<endl;
		cout<<"Assignment grade:";
		cout<<s1.assignmentgrade<<endl;
	}
int main(){
	Student Students[5];
	Students[i].examgrade;
	return 0;
}

