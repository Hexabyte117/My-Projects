/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edus
	Date: 11/30/17
	Intructor: Helsing
	Description: Integers from keyboard
*/
#include <iostream>
#include <cstdlib>
#include <cstddef>
using namespace std;

int main(){
	typedef double* DoublePtr;
	DoublePtr numlist;
	numlist = new double[8];
	//read 8 integers from keyboard
	for(int i=0; i<8; i++){
		cout<<"Enter value at index "<<i<<" :";
		cin>>numlist[i];
	}
	//display the numbers at odd indices
        for(int i=1; i<8;i=i+2){
                cout<<"Print value at index "<<i<<" :";
		cout<<numlist[i]<<endl;
        }
	delete numlist;

	return 0;
}

