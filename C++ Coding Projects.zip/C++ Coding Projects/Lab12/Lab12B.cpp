/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edus
	Date: 11/30/17
	Intructor: Helsing
	Description: 2D arrays 
*/
#include <iostream>
#include <cstdlib>
#include <cstddef>
using namespace std;

int main(){
	int Size, numCols, numRows;
	cout<<"Enter the rows and columns for your matrix:";
	cin>>numCols>>numRows;
	typedef int* DoublePtr;
	DoublePtr *p_2D;
	p_2D = new int*[numRows];
	for(int i=0; i<numRows; i++) {    
		 p_2D[i] = new int[numCols];
	}   
	//read 8 integers from keyboard
	for(int i=0; i<numRows; i++){
		  for(int j=0; j<numCols; j++)
                	{
				cout<<"Enter value at index "<<" Row: "<<i+1<<" Column: "<<j+1<<" :";

                        	cin >> p_2D[i][j];
                	}

	}
	//display the numbers at odd indices
        for(int i=1; i<numRows; i=i+2){
		for(int j=0; j<numCols; j++){
                	cout<<"Print value at index \n "<<" Row: "<<i+1<<" Column: "<<j+1<<" :";
			cout<<p_2D[i][j]<<endl;
		}
        }
	for(int i=0; i<numRows; i++) {     
		 delete [] p_2D[i];    
	}  
	delete p_2D;
	//p_2D = NULL;

	return 0;
}

