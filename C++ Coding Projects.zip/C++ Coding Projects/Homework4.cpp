/*
*******************************************************
Computer Science and Engineering
CSCE 1030 - Computer Science I
Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu
*******************************************************
*/
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <cctype>
using namespace std;

void encrypt(ifstream& inputFile, ofstream& outputFile);
void decrypt(ifstream& inputFile, ofstream& outputFile);

int main() {
cout << "*******************************************************\n";
cout << "Computer Science and Engineering\n";
cout << "CSCE 1030 - Computer Science I\n";
cout << "Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu\n";
cout << "*******************************************************\n";

    //http://en.cppreference.com/w/cpp/language/ascii

    cout << "Header" << endl;

    char encryptOrDecrypt;
    cout << "Would you like encrypt or decrypt a file? Enter 'e' or 'd' : ";
    cin >> encryptOrDecrypt;
    while ((encryptOrDecrypt!='e')&&(encryptOrDecrypt!='d')) {
        cout << "ERROR: Invalid entry" << endl;
        cout << "Would you like encrypt or decrypt a file? Enter 'e' or 'd' : ";
        cin >> encryptOrDecrypt;
    }

    char fileNameInput[33];
    cout << "Enter the name of the file you would like to open as input: ";
    cin >> fileNameInput;
    ifstream inputFile;
    inputFile.open(fileNameInput);
    if (inputFile.fail()) {
        cout << "That file does not exist. Exiting program." << endl;
        exit (EXIT_FAILURE);
    }

    char fileNameOutput[33];
    cout << "Enter the name of the file you would like to open for output: ";
    cin >> fileNameOutput;
    ofstream outputFile;
    outputFile.open(fileNameOutput);

    if(encryptOrDecrypt=='e') {
        encrypt(inputFile,outputFile);
    }

    else if(encryptOrDecrypt=='d') {
        decrypt(inputFile,outputFile);
    }

    return 0;

}
/* 
 ============================================================================ 
 Function    : Encrypt
 Parameters  : a ifstream representing input file and ofstream to represent
	       output file stream	 
 Return      : void has no return value
 Description : This function encrypts the file and outputs the data on a file 
 ============================================================================ 
 */

void encrypt(ifstream& inputFile, ofstream& outputFile) {

    char nextChar;
    int charCount=0;
    int encryptInt;

    cout << "The program will now encrypt your file..." << endl;

    char fileNameKeys[33];
    cout << "Enter the name of the file that will contain the encryption keys: ";
    cin >> fileNameKeys;
    ofstream encryptionFile;
    encryptionFile.open(fileNameKeys);

    //cout << endl << "Data before omitting duplicate last character : " << endl;
    while (!inputFile.eof()) {
        inputFile.get(nextChar);
        charCount++;
        //cout << nextChar;
    }
    //cout << endl;

    srand(time(NULL));
    //cout << "Data after omitting duplicate last character : " << endl;
    inputFile.clear();
    inputFile.seekg(0, ios::beg);
    for (int readCount=0; readCount<charCount-1; readCount++) {
        inputFile.get(nextChar);
        //cout << nextChar;
        if (isalpha(nextChar)) {
            if (isupper(nextChar)) {
                encryptInt = rand() % 275 + 2;
                //cout << "Wrote " << encryptInt << " to key file" << endl;
                encryptionFile << encryptInt << endl;
                //cout << nextChar << " ";
                //cout << static_cast<int> (nextChar) << " ";
                //cout << encryptInt%26 << " ";
                if ((nextChar+(encryptInt%26)>90)) {
                    nextChar=nextChar-(26-(encryptInt%26));
                }
                else {
                    nextChar=(nextChar+(encryptInt%26));
                }
                //cout << static_cast<int> (nextChar) << " ";
                //cout << nextChar << " " << endl;
                outputFile.put(nextChar);
            }
            else if (islower(nextChar)) {
                encryptInt = rand() % 275 + 2;
                //cout << "Wrote " << encryptInt << " to key file" << endl;
                encryptionFile << encryptInt << endl;
                //cout << nextChar << " ";
                //cout << static_cast<int> (nextChar) << " ";
                //cout << encryptInt%26 << " ";
                if ((nextChar+(encryptInt%26)>122)) {
                    nextChar=nextChar-(26-(encryptInt%26));
                }
                else {
                    nextChar=(nextChar+(encryptInt%26));
                }
                //cout << static_cast<int> (nextChar) << " ";
                //cout << nextChar << " " << endl;
                outputFile.put(nextChar);
            }
        }
        else if (isdigit(nextChar)) {
                encryptInt = rand() % 275 + 2;
                //cout << "Wrote " << encryptInt << " to key file" << endl;
                encryptionFile << encryptInt << endl;
                //cout << nextChar << " ";
                //cout << static_cast<int> (nextChar) << " ";
                //cout << encryptInt%10 << " ";
                if ((nextChar+(encryptInt%10)>57)) {
                    nextChar=nextChar-(10-(encryptInt%10));
                }
                else {
                    nextChar=(nextChar+(encryptInt%10));
                }
                //cout << static_cast<int> (nextChar) << " ";
                //cout << nextChar << " " << endl;
                outputFile.put(nextChar);
        }
        else if (ispunct(nextChar)) {
            outputFile.put(nextChar);
            //cout << "Wrote " << encryptInt << " to key file" << endl;
            encryptionFile << "-1" << endl;
        }
        else if (isspace(nextChar)) {
        }
        else {
            cout << "ERROR: The program has encountered an invalid character." << endl;
        }
    }

    cout << "Encryption successful" << endl;

    inputFile.close();
    outputFile.close();
    encryptionFile.close();

}
/* 
 ============================================================================ 
 Function    : Decrypt
 Parameters  : a ifstream representing input file and ofstream to represent
	       output file stream	 
 Return      : void has no return value
 Description : This function decrypts the file and outputs the data on a file 
 ============================================================================ 
 */
void decrypt(ifstream& inputFile, ofstream& outputFile) {

    char nextChar;
    int charCount=0;
    int encryptInt;

    cout << "The program will now decrypt your file..." << endl;

    char fileNameKeys[33];
    cout << "Enter the name of the file that will contain the encryption keys: ";
    cin >> fileNameKeys;
    ifstream encryptionFile;
    encryptionFile.open(fileNameKeys);
    if (encryptionFile.fail()) {
        cout << "That file does not exist. Exiting program." << endl;
        exit (EXIT_FAILURE);
    }

    while (!inputFile.eof()) {
        inputFile.get(nextChar);
        charCount++;
        //cout << nextChar;
    }
    //cout << endl;

    inputFile.clear();
    inputFile.seekg(0, ios::beg);
    for (int readCount=0; readCount<charCount-1; readCount++) {
        inputFile.get(nextChar);
        //cout << nextChar;
        //cout << "Read: " << nextChar << endl;
        encryptionFile >> encryptInt;
        //cout << "Corresponding encryption number: " << encryptInt << endl;
        if (encryptInt!=-1) {
            //cout << "Encryption number " << encryptInt << " has passed into the not -1 case" << endl;
            //cout << nextChar << " is the value of nextChar within the loop." << endl;
            if (isalpha(nextChar)!=0) {
                //cout << nextChar << " is passing through the alpha case." << endl;
                if (isupper(nextChar)!=0) {
                    //cout << "I have encountered an uppercase character." << endl;
                    if ((nextChar-(encryptInt%26))<65) { //Ex. B@66 - 6 is 60 but is actually 86
                        nextChar=nextChar+26-(encryptInt%26);
                        outputFile.put(nextChar);
                    }
                    else {
                        nextChar=nextChar-(encryptInt%26);
                        outputFile.put(nextChar);
                    }
                }
                else if (islower(nextChar)!=0) {
                    //cout << "I have encountered a lowercase character." << endl;
                    if ((nextChar-(encryptInt%26))<97) {
                        nextChar=nextChar+26-(encryptInt%26);
                        outputFile.put(nextChar);
                    }
                    else {
                        nextChar=nextChar-(encryptInt%26);
                        outputFile.put(nextChar);
                    }
                }
            }
            if (isdigit(nextChar)!=0) {
                //cout << nextChar << " is passing through the digit case." << endl;

                if ((nextChar-(encryptInt%10))<48) {
                    nextChar=nextChar+10-(encryptInt%10);
                    outputFile.put(nextChar);
                }
                else {
                    nextChar=nextChar-(encryptInt%10);
                    outputFile.put(nextChar);
                }
            }
        }
        else if (encryptInt==-1) {
            //cout << nextChar;
            outputFile.put(nextChar);
        }
    }

    cout << "Decryption successful" << endl;

    inputFile.close();
    outputFile.close();
    encryptionFile.close();

}
