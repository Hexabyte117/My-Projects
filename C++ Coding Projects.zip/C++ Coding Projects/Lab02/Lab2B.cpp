#include <iostream>
using namespace std;
int main()
{
int ft; //user input for feet
int in; //user input for inches
int Height_inches;
//ask for input for feet
cout<< "Feet:";
cin>> ft;
//ask for input for inches
cout<< "Inches:";
cin>> in;
//calculate inches by converting feet and inches to inches
Height_inches = in+12*ft;
cout<< "Your height in feet and inches is "<<ft<<"feet "<<in<<"inches "<<endl;
cout<< "Your height in inches is " <<Height_inches<<"\n";
return 0;
}
