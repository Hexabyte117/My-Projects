/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/22/17
	Intructor: Helsing
	Description: Convert c-string to string
*/
//This program reads some integers from a file and displays:
//The number, number^(1/2), and the sum of all square roots to that point
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <string>
#include <cstring>
#include <cctype>
using namespace std;

int main () {
    int x, count = 0;
    float sum = 0, avg;
    char input_file[15]; //convert input_file C-string to be a string
    for (int i=0; i<14; i++) { // initializes c-string to all space except for terminating character
        input_file[i]=' ';
    }

    ifstream in_s;

    cout << "Please enter the input file name: ";
    cin >> input_file;

    string convertedToString; // declare string
    for (int i=0; i<14; i++) { // see content of c-string except for terminating character
        if (isspace(input_file[i])==0) { // if the character isn't a space
            convertedToString.push_back(input_file[i]); // put the character into a string
        }
    }
    cout << "The c-string was converted to a string with contents: " << convertedToString << endl;

    char convertedToCString[15];
    strcpy(convertedToCString, convertedToString.c_str());
    cout << "The string was converted to a c-string with contents: " << convertedToCString << endl;

    in_s.open(input_file); //convert input_file string to a C-string
    if (in_s.fail()) {
        cout << "ERROR: Unable to open input.\n";
        exit(EXIT_FAILURE);
    }

    cout << "\t  x  \t\t x^(1/2) \t Current Sum \n";
    cout << "\t === \t\t ======== \t ========== \n";

    while(in_s >> x) {
        sum = sum + sqrt(x);
        cout << "\t " << x << "\t\t " << sqrt(x) << "\t\t " << sum << "\n";
        count++;
    }

    avg = sum/count;
    cout << "\n \t The average of these " << count << " square roots is: " << avg << endl;

    in_s.close();

    return 0;
}
