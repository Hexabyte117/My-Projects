/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/22/17
	Intructor: Helsing
	Description: Dynamic variables
*/
#include <iostream>
using namespace std;

int main () {

    double *pumpkinPI = new double;

    cout << "Enter the number of PI's: ";
    cin >> *pumpkinPI;
    *pumpkinPI = *pumpkinPI * (2*3.14*4);
    cout << "Your 8 inch pumpkin PI's have a combined circumference of " << *pumpkinPI << " inches." << endl;

    delete pumpkinPI;

    return 0;

}
