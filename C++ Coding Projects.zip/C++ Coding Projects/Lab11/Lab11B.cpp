/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/22/17
	Intructor: Helsing
	Description: Introductions to pointers
*/
#include <iostream>
using namespace std;

int main() {
    int num;
    char ch;
    float val;

    int *numPtr=NULL;
    char *chPtr=NULL;
    float *valPtr=NULL;

    numPtr=&num;
    chPtr=&ch;
    valPtr=&val;

    cout << "num is " << num << endl;
    cout << "ch is " << ch << endl;
    cout << "val is " << val << endl;

    cout << "num's address is " << &num << endl;
    cout << "ch's address is " << &ch << endl;
    cout << "val's address is " << &val << endl;

    cout << "pointer to the num's address is " << numPtr << endl;
    cout << "pointer to the ch's address is " << chPtr << endl;
    cout << "pointer to the val's address is " << valPtr << endl;

    return 0;
}
