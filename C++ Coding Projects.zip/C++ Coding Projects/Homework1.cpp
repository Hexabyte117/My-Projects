#include <iostream>
using namespace std;
int main()
{
float Th; //user input for temperature for heat reservoir
float Tc; //user input for temperature of the cold reservoir
float Tk; //user input for temperature in kelvin
float n1; //user input for original efficiency
float n2; //user input for increased efficiency
float DeltaTh;
float Tcel; //user input for temperature in celsius
cout<< "Computer Science and Engineering CSCE 1030-Computer Science I Elijah Goodrich 10813898 Elijahgoodrich@my.unt.edu\n";
cout<< "Enter the original Carnot efficiency (0 < n1 < 1):";
cin>> n1;
cout<< "Enter the original Carnot efficiency (0 < n2 < 1 and n1 < n2):";
cin>> n2;
cout<< "Enter the temperature of the cold reservoir in Celsius:";
cin>> Tcel;
//Tc = Tk; //user input for hot reservoir in kelvin
DeltaTh = (Tcel+273.15)/(1-n2) - ((Tcel+273.15)/(1-n1));
//Tk = Tcel+273.15; //user input to celsius to kelvin
cout<< "The temperature of the hot reservoir must increase by " <<DeltaTh<<"K"<<endl;
return 0;
}
