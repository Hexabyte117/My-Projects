#include <stdio.h>
using namespace std;

int main()

{
/*
i is the initial value that the factorial will increase by
n is the number you enter for the factorial
factorial is the total value for our n!
*/
	int i, n, factorial=1;  
	printf("Please enter your value n to solve as a factorial: ");
	scanf("%i",&n);
	if(n<0)
	{
		printf("Please enter a non-negative value for n!: ");
		scanf("%i",&n);
	}
	for(i=1; i<=n; ++i) {
		factorial *=i; //factorial= factorial * i;
	}
	printf("Factorial of %i! = %i\n",n,factorial);
	return 0;
}
