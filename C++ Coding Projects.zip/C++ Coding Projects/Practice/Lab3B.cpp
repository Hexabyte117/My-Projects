#include <stdio.h>
using namespace std;

int main()
{
	float num1, num2, num3;
	int divider=2;

	printf("Today is a great day for lab!\n");
	printf("Let's start off by entering an even number:\n ");
	scanf("%f",&num1);
	num2 = num1/divider;
	printf("One half of %f is %f \n",num1,num2);
	num3 = num1;
	num1 = num2;
	num2 = num3;
	printf("Two times %f is %f \n",num1,num2);
	
	return 0;
}
