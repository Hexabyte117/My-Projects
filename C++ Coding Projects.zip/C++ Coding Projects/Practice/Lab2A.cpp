#include <iostream>
using namespace std;

int main()
{
	cout<<"This program contains several syntax errors. \n";
	cout<<"These need to be fixed berfore you sumbmit it. \n";
	cout<<"Fixed by esg0031. \n";
	return 0;
}
