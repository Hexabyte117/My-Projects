#include <iostream>
using namespace std;
int main()

{
	float num1, num2, num3, num4;
	cout<<"Please enter your first value: "<<endl;
	cin>>num1;
	cout<<"Please enter your second value: "<<endl;
        cin>>num2;
	num3=num1/num2;
	cout<<"Please enter the amount of decimal places that you want to round up from: "<<endl;
	cin>>num4;
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(num4);
	cout<<"Your first value divided by the second values equals "<<num3<<endl;
return 0;
}
