#include <stdio.h>
using namespace std;

int main()
{
	int a,b;
	double c,d;
	printf("Enter your values for a, b, c, d: ");
	scanf("%i%i%lf%lf",&a,&b,&c,&d);
	printf("You just entered a: %i b: %i c: %lf d: %lf:\n ",a,b,c,d);
	a+=b;
	d/=b;
	c*=2;
	a%=b;
	c-=a;
	printf("Your values are a: %i b: %i c: %lf d: %lf\n",a,b,c,d);
	return 0;
}
