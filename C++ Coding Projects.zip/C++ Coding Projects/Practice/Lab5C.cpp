#include <iostream>
using namespace std;

int main()
{
	int firstOperand, secondOperand;
	int operation;
	cout<<"Enter the first number: ";
	cin>>firstOperand;
	cout<<"Enter the second: ";
	cin>>secondOperand;
	cout<<"Enter the operation to be performed (1=ADD, 2=SUBSTRACT, 3=MULTIPLY,4=DIVIDE):";
	cin>>operation;
	switch (operation)
	{
	case 1:	{
		cout<<"The result of adding "<<firstOperand<<" with "<<secondOperand<<" is: "<< firstOperand+secondOperand<<endl;
	break;
		}	
	case 2: {
	cout<<"The result of subtracting "<<secondOperand<<" from "<<firstOperand<<" is: "<<firstOperand-secondOperand<<endl;
	break;
	}
	case 3: {
        cout<<"The result of multiplying "<<firstOperand<<" with "<<secondOperand<<" is: "<<firstOperand*secondOperand<<endl;
	}
	case 4: {
        cout<<"The result of dividing "<<firstOperand<<" with "<<secondOperand<<" is: "<<firstOperand/secondOperand<<endl;
	break;
	}
	}		
	return 0;
}

