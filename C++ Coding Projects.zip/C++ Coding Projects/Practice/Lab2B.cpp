#include <iostream>
using namespace std;

int main()
{
int Feet, Inches, Total_Inches;

cout<<"Please enter you height in feet and inches:"<<endl;
cin>>Feet>>Inches;
Total_Inches = 12*Feet + Inches;
cout<<"Your height in feet and inches is "<<Feet<<" feet "<<Inches<<" inches. Your height in inches is "<<Total_Inches<<" inches."<<endl;
return 0;
}
