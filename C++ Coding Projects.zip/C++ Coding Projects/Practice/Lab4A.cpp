#include <stdio.h>
using namespace std;

int main()
{
	char letter1, letter2, letter3, letter4, letter5;
	printf("Please enter the letters of your friend\'s code word: ");
	scanf("%c%c%c%c%c",&letter1,&letter2,&letter3,&letter4,&letter5);
	letter1-=1;
	letter2-=1;
	letter3-=1;
	letter4-=1;
	letter5-=1;
	printf("The code word was: %c%c%c%c%c \n",letter1, letter2, letter3, letter4, letter5);
	printf("%d%d%d%d%d \n",letter1, letter2, letter3, letter4, letter5);
	return 0;
}
