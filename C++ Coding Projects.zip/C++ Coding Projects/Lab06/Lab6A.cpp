/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date:10/12/17
	Intructor: Helsing
	Description: Changing code with pow and sqrt
*/
#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int i = 0, p ;
	int a = 2, b = 3;
	p=pow(a,b);
	cout << a << " to the power of " << b << " is = " << p << endl;
	i=0, p;
	a=4, b=5;
	p=pow(a,b);
	cout << a << " to the power of " << b << " is = " << p << endl;
	double s;
	a=16;
	s=sqrt(a);
	cout<< "The square root of "<<a<<" is = "<<s<<endl;
	return 0;
}
