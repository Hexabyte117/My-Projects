/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/12/17
	Intructor: Helsing
	Description:Random number
*/
#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
int main()
{
	int rndm,i;
	srand(time(NULL));
	for(int i=1;i<=10;i++)
	{
		rndm=(rand()%8)-2;
		cout<<"Random #"<< i <<" is "<<rndm<<endl;
	}
	cout<<endl;
	return 0;
}

