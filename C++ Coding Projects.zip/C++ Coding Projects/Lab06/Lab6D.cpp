/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/12/17
	Intructor: Helsing
	Description: comparing two doubles
*/
#include <iostream>
using namespace std;
double max(double num1, double num2);
int main()
{
	double num1,num2,num3;
	cout<<"Please enter your value for num1 and num2: ";
	cin>>num1>>num2;
	 num3=max(num1,num2);
	cout<<"The largest value is: "<<num3<<endl;

	return 0;
}
double max(double num1, double num2) {
 	if (num1>num2)
        {
                return num1;
        }
        else
        {
                return num2;
        }
}

