/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 10/12/17
	Intructor: Helsing
	Description: Type casting
*/

#include <iostream>
using namespace std;
/*
int main()
{
	int x,y;
	cout<<"Enter 2 values for x and y seperated by space, then press <Enter>:";
	cin>>x>>y;
	cout<<x<<"/"<<y<<"-"<<x/static_cast<double>(y)<<endl;
	cout<<"Right after type casting "<<x<<"/"<<y<<"="<<x/y<<endl;
	return 0;
} */

int main()
{
        int kilometers;
        double miles;

        cout<<"Enter the area in square kilometers \n";
        cin>>kilometers;
	miles=kilometers*25/static_cast<double>(64);
	cout<<"The area in square miles is "<<miles<<endl;
	return 0;
}

