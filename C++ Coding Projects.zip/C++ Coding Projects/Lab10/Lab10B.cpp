/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/16/17
	Intructor: Helsing
	Description: selection sort
*/
#include <iostream>
using namespace std;

void selection_sort(int a[],int size);
void swap_values(int& fnumber, int& snumber);

int index_of_smallest( int a[], int star_index, int number_used);

int main()
{
        const int SIZE = 10;
        int numbers[SIZE] = {6,7,2,1,100,1000,12,13,80,0};
        cout << "This program sorts the following numbers in descending order using selection sort:" << endl;

        for(int i=0; i<10; i++)
        {
                cout << numbers[i] << endl;
        }

        //calling selection sort

        selection_sort(numbers,10);
        cout << "The numbers after being sorted:" << endl;
        for(int i=0;i<10;i++)
        {
                cout << numbers[i] << endl;
        }

        return 0;
}

void selection_sort(int a[], int size)
{
        int index_of_next_smallest;

        for(int i=0;i<size;i++)
        {
                index_of_next_smallest = index_of_smallest(a,i,size);
                swap_values(a[i],a[index_of_next_smallest]);
        }
}

void swap_values (int& v1, int& v2)
{
        int temp;
        temp = v1;
        v1 = v2;
        v2 = temp;
}

int index_of_smallest(int a[], int start_index, int size)
{
        int min = a[start_index];
        int index_of_min = start_index;

        for(int i = start_index + 1; i<size;i++)
        {
                if(a[i]>min)
                {
                        min = a[i];
                        index_of_min = i;
                }
        }
        return index_of_min;
}
