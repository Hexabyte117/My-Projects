/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/16/17
	Intructor: Helsing
	Description: spooky time with arrays
*/
#include <iostream>
using namespace std;

const int ROWS = 3;
const int COLS = 4;

void printMatrix(int matrix[][COLS]);
void readMatrix(int matrix[][COLS]);
void addMatrix(int matrix1[][COLS], int matrix2[][COLS], int matrix3[][COLS]);

int main()
{
        int matrix1[ROWS][COLS];
        int matrix2[ROWS][COLS];
        int matrix3[ROWS][COLS];

        cout << "Enter numbers to fill out the first matrix: " << endl;
        readMatrix(matrix1);
        cout << "Printing Matrix 1: " << endl;
        printMatrix(matrix1);
        cout << "Enter numbers to fill out the second matrix: " << endl;
        readMatrix(matrix2);
        cout << "Printing Matrix 2: " << endl;
        printMatrix(matrix2);
        cout << "Adding the two Matrices: " << endl;
        addMatrix(matrix1,matrix2,matrix3);
	printMatrix(matrix3);
        return 0;
}

//reads in the elements of a matrix
void readMatrix(int matrix[][COLS])
{
        for(int i=0;i<ROWS;i++)
        {
                for(int j=0; j<COLS;j++)
                {
                        cin >> matrix[i][j];
                }
        }
}

//prints the elements of a matrix
void printMatrix (int matrix[][COLS])
{
	for (int i = 0; i < ROWS; i++)
    	{	
        	for (int j = 0; j < COLS;j++)
        	{
            		cout << matrix[i][j] << ' ';
        	}
        cout <<endl;
    }

}

//adds up the corresponding elements of two matrices and saves the result in a third matrix
void addMatrix(int matrix1[][COLS],int matrix2[][COLS], int matrix3[][COLS])
{
        for (int i = 0; i < ROWS; i++)
        {
                for (int j = 0; j < COLS; j++)
                {
                        matrix3[i][j]= matrix2[i][j] + matrix1[i][j];
                }
    }
	
        
}

