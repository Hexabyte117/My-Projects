/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 11/16/17
	Intructor: Helsing
	Description: Passing arrays through function
*/

#include <iostream>
using namespace std;

void double_it(int number[],int SIZE);

int main(void){
	int numbers[5]={0};
	int i;
	int SIZE=5;
	cout<<"Enter five numbers:";
	for(i=0;i<5;i++){
		cin>>numbers[i];
	}
	cout<<"Printing the array before calling the double_it function:"<<endl;
	for(i=0;i<5;i++){
		cout<<numbers[i]<<endl;
	}

              double_it(numbers,5);
        
	cout<<"Printing the array after calling the double_it function:"<<endl;
	for(i=0;i<5;i++){
		cout<<numbers[i]<<endl;
	}
	return 0;
}
void double_it(int number[],int SIZE){
	int i;
	for(i=0;i<SIZE;i++){
        number[i]=number[i]*2;
        }

}

