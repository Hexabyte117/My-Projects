/*	 Author: Elijah Goodrich elijahgoodrich@my.unt.edu
	Date: 9/21/17
	Intructor: Helsing
	Description: Flow control using if else statements
*/
#include <iostream>
using namespace std;

int main()
{
	int numCookies;
	double singleCookiePrice = 1.25;
	double totalCost; 
	cout << "Please enter the number of cookies the customer ordered: ";
	cin >> numCookies;
	if(numCookies < 12)
	{
		cout << "Your value" << numCookies << " was less than 12" << endl;
		totalCost =numCookies*1.25;
	}
	else
	{
		cout << "Your value" << numCookies << " was greater than or equal to 12." << endl;
		totalCost = 0.9*numCookies*1.25;
	}
        // Use if else statements to calculate the correct total price of the order
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(2);
	cout << "The total cost of the order is $" << totalCost << endl;
	return 0;
}
