/*
	Author: Elijah Goodrich  Elijahgoodrich@my.unt.edu
	Date: 9/21/17
	Instructor: Helsing
	Deescription: A series of computation using short hand notation and printf and scanf.
*/
#include <stdio.h>
int main()
{
	int a, b;
	double c, d;
	printf("Enter your values for a b c d:");
	scanf("%i%i%lf%lf", &a, &b, &c, &d);
	printf("You just entered %i %i %lf %lf: ",a,b,c,d);
	
	a += b;
	d /= b;
	c *= 2;
	a %= b;
	c -= a;
	printf("Your values are %i %i %lf %lf: ", a, b, c, d);
	return 0;
}
