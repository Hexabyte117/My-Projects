#include <iostream>
#include <stdio.h>
using namespace std;

void printTriangle(int rows);
bool userInputValid(int userEntry);
int factorial(int integer);

int main()
{
cout << "*******************************************************\n";
cout << "Computer Science and Engineering\n";
cout << "CSCE 1030 - Computer Science I\n";
cout << "Elijah Goodrich    10813898   elijahgoodrich@my.unt.edu\n";
cout << "*******************************************************\n";

/*
k is the equal value that is in range of 2-12
nj is the prior value of ni for your factorial
ni is the initial value for your factorial
space is an integer value and is also less than rows-i
i is the amount of iterations being ran
j=i-1 for the subscript of n
k%2=0 is the even and k%2!=0 is an odd number
j is also the amount of iterations being ran for our function
row is the number of rows being place and the upper bound for our function
*/
int k;

cout<<"Please enter an even number in the range of 2 - 12: ";
cin>>k;
while(userInputValid(k)==false) {
    cout << "Invalid entry - Please enter an even number in the range of 2 - 12: " << endl;
    cin>>k;
} //At this point, k is a valid value

cout << endl;
cout << "The product of integers from 1 to " << k << " : " << factorial(k) << endl;

cout << endl;
printTriangle(k);

return 0;
}

void printTriangle(int rows) //Prints triangle
 {
			int i,j,n;
			for(i=1;i<=rows;i++)
			{
				for (int space = 0; space < rows-i; space++)
				{
					cout << "    ";
				}
				for(j=1;j<=i;j++)
				{
					cout.width(3);
					cout<<right<<i<<" ";
				}
				cout<<endl;
			}
}

bool userInputValid(int userEntry) //Checks if function is odd or even then returns a value of true or false to the int main
{
    if((userEntry<2) || (userEntry>12) || (userEntry%2!=0))
        {
            return false;
        }
    else
        {
            return true;
        }
}

int factorial(int integer) //Factorial function returns nj to int main
{
    int nj=1,ni=1;
    while(ni<=integer)
        {
            nj = nj * ni;
            ni++;
        }
            ni=ni-1;
            return nj;
}
