#include <iostream>
using namespace std;

int main()
{
float num1, num2, num3, num4;
cout << endl << "Enter the first decimal value: ";
cin >> num1;
cout << endl << "Enter the second decimal value: ";
cin >> num2;
cout << endl << "Enter the amount of decimals that you want to round up to: ";
cin >> num4;
num3 = num1 / num2;
cout.setf(ios::fixed);
cout.setf(ios::showpoint);
cout.precision(num4);
cout << "Your value is: " << num3 << endl;
return 0;
}
