#include <iostream>
using namespace std;

int main( )
{
float var1;
float var2;
char var3;
int var4;
float var5;

var1 = 39.4;
var2 = 7.6;
var3 = 'B';
var4 = 22;

//expression must be equal to 25.5
var5 = ((var3-var1)/var2)+var4;

cout << var5 << endl; //this should print 25.5
return 0;
}
