#include <iostream>
using namespace std;

int main()
{
float num1, num2, num3;
int divider;

divider = 2;
cout<< "Today is a great day for a lab!";
cout << endl << "Let's start off by entering an even number: ";
cin >> num1;

//calculate half of the even number
num2 = num1/divider;
 cout << "One-half of " << num1 << " is " << num2 << endl;

// Now let's swap these numbers and print out the opposite 
num3 = num1;
num1 = num2;
num2 = num3;
cout << "Two times " << num1 << " is " << num2 << endl;
return 0;

}
