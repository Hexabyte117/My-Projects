%Elijah Goodrich
clc
clear all
%syms k
func=@(k) (10)*exp(-k*150*10^-3*10.5)-.5;
xl=0.1;
xu=10;
es=0.001;
maxit=50;
actualvalue=1.90205
[Root]=bisect(func, xl, xu, es, maxit)
[RootFalsepos]=falsepos(func, xl, xu, es, maxit)
function [root, ea, iter] = bisect(func, xl, xu, es, maxit, varargin)
%Usage:
%   [root, eq, iter]=bisect(func, xl, xu, es, maxit, p1, p2, ...)
%   uses bisection to find the root of an equation
%Input:
%   func = the name of the function
%   xl, xu = the lower and upper bounds
%   es = desired relative error (default = 0.0001%)
%   maxit = maximum allowable iterations (default = 50)
%   p1, p2, ... = additional parameters
%Output:
%   root = the real root
%   ea = the approximate error
%   iter = the number of iterations

%check if the arguments are present
%set default parameter if certain arguments are not present
if nargin<3, error ('at least 3 input arguments required'),end
%check to make sure that a root lies between the points
test = func(xl,varargin{:})*func(xu,varargin{:});
%give error if no root is detected
if test>0,error('no sign change'),end
%set more defaults if arguements are not present
if nargin<4|isempty(es), es=0.0001;,end
if nargin<5|isempty(maxit),maxit=50;,end
%initialize xr and iter to starting values
iter=0; xr=xl;
while(1)
    xrold = xr; %Initialize the initial gues
    xr = (xl + xu)/2;   %Calculate the midpoint
    iter = iter+1;
    if xr~= 0 
        ea = abs((xr-xrold)/xr)*100;    % find the midpoint
    end
    test = func(xl,varargin{:})*func(xr,varargin{:});    
    %check if mipoint is positive or negative
    if test < 0
        %if positive assign as new upper bound
        xu = xr;
    elseif test > 0
        %if negative assign as the lower bound
        xl = xr;
    else
        %if value is equal to zero, root has been found
        ea = 0;
    end
    %break conditions
    if (ea<= es | iter>= maxit)
        break
    end
end
%set the root equal to the approximation
root = xr;
%bisectk=double(root/(10^6))
end
function [root, ea, iter] = falsepos(func, xl, xu, es, maxit, varargin)
%Usage:
%   [root, eq, iter]=falsepos(func, xl, xu, es, maxit, p1, p2, ...)
%   uses bisection to find the root of an equation
%Input:
%   func = the name of the function
%   xl, xu = the lower and upper bounds
%   es = desired relative error (default = 0.0001%)
%   maxit = maximum allowable iterations (default = 50)
%   p1, p2, ... = additional parameters
%Output:
%   root = the real root
%   ea = the approximate error
%   iter = the number of iterations

%check if the arguments are present
%set default parameter if certain arguments are not present
if nargin<3, error ('at least 3 input arguments required'),end
%check to make sure that a root lies between the points
test = func(xl,varargin{:})*func(xu,varargin{:});
%give error if no root is detected
if test>0,error('no sign change'),end
%set more defaults if arguments are not present
if nargin<4|isempty(es), es=0.0001;,end
if nargin<5|isempty(maxit),maxit=50;,end
%initialize xr and iter to starting values
iter=0; xr=xl;
while(1)
    xrold = xr; %Initialize the initial gues
    xr=xu-func(xu,varargin{:})*(xl-xu)/(func(xl,varargin{:})-func(xu,varargin{:}));   
    %Calculate the new point from the false position formula
    iter = iter+1;
    if xr~= 0 
        ea = abs((xr-xrold)/xr)*100;    % find the midpoint
    end
    test = func(xl,varargin{:})*func(xr,varargin{:});    
    %check if new value is positive or negative
    if test < 0
        %if positive assign as new upper bound
        xu = xr;
    elseif test > 0
        %if negative assign as the lower bound
        xl = xr;
    else
        %if value is equal to zero, root has been found
        ea = 0;
    end
    %break conditions
    if (ea<= es | iter>= maxit)
        break
    end
end
%set the root equal to the approximation
root = xr;
end
%note that the answers will be multiplied by 10^-9 when you divide mM by 1
%million cells, left it out to computationally solve problem.