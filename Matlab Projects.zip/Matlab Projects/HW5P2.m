%Elijah Goodrich
clc
clear all
%% part a
syms x
f=(x.^3)-(6*x.^2)+11.*x-6.1;
a0=fplot(f,x)
%% part b,c,d

func=@(x) (x.^3)-(6*x.^2)+11.*x-6.1;
dfunc=@(x) 3*(x.^2)-(12*x)+11;
xr=3.5;
xrold=2.5;
es=0.0001;
maxit=3;
deltaxr=.01;
[SecantRoot IterAns]=secant(func,xr,xrold,es,maxit)
Newtraph=newtraph(func,dfunc,xr,es,maxit)
ModSecant=modsecant(func,xr,deltaxr,es,maxit)
function [root,xmat,ea,iter]=secant(func,xr,xrold,es,maxit,varargin)
% Usage:
%   [root,ea,iter]=secant(fun,dfunc,xr,es,maxit,p1,p2...)
%   Uses the secant method to find the root of func
% Input:
%   func = name of function
%   xr = initial guess
%   xrold = second guess
%   es = desired relative error (default = 0.0001%)
%   maxit = maximum allowable iterations (default = 50)
%   p1, p2, ... = additional parameters
%Output:
%   root = the real root
%   ea = the approximate error
%   iter = the number of iterations

%check if the arguements are present
%set default parameter if certain arguements are not present
if nargin<3, error ('at least 3 inpu arguements required'),end
%set more defaults if arguements are not present
if nargin<4|isempty(es), es=0.0001;,end
if nargin<5|isempty(maxit),maxit=50;,end
%initialize xr and iter to starting values
iter = 0;
xmat=xr;
while(1)
        xi = xr;
        xr = xr-func(xr,varargin{:})*(xrold-xr)/(func(xrold,varargin{:})-func(xr,varargin{:}));
        iter = iter + 1;
        xrold = xi;
        if xr ~= 0
            ea = abs((xr-xrold)/xr)*100;
            
        end
        xmat(iter+1,1)=xr;
        if (ea<=es | iter >= maxit)
            break
        end
end
root = xr;
end
function [root,ea,iter]=newtraph(func,dfunc,xr,es,maxit,varargin)
% Usage:
%   [root,ea,iter]=secant(fun,dfunc,xr,es,maxit,p1,p2...)
%   Uses the secant method to find the root of func
% Input:
%   func = name of function
%   dfunc = name of erivative of function
%   xr = initial guess
%   es = desired relative error (default = 0.0001%)
%   maxit = maximum allowable iterations (default = 50)
%   p1, p2, ... = additional parameters
%Output:
%   root = the real root
%   ea = the approximate error
%   iter = the number of iterations

%check if the arguements are present
%set default parameter if certain arguements are not present
if nargin<3, error ('at least 3 inpu arguements required'),end
%set more defaults if arguements are not present
if nargin<4|isempty(es), es=0.001;,end
if nargin<5|isempty(maxit),maxit=50;,end
%initialize xr and iter to starting values
iter = 0;
while(1)
        xrold =  xr;
        xr = xr-func(xr)/dfunc(xr);
        iter = iter + 1;
        if xr ~= 0
            ea = abs((xr-xrold)/xr)*100;
        end
        if (ea<=es | iter >= maxit)
            break
        end
end
root = xr;
end
function [root,ea,iter]=modsecant(func,xr,deltaxr,es,maxit,varargin)
% Usage:
%   [root,ea,iter]=secant(fun,dfunc,xr,es,maxit,p1,p2...)
%   Uses the secant method to find the root of func
% Input:
%   func = name of function
%   xr = initial guess
%   xrold = second guess
%   es = desired relative error (default = 0.0001%)
%   maxit = maximum allowable iterations (default = 50)
%   p1, p2, ... = additional parameters
%Output:
%   root = the real root
%   ea = the approximate error
%   iter = the number of iterations

%check if the arguments are present
%set default parameter if certain arguments are not present
if nargin<3, error ('at least 3 input arguments required'),end
%set more defaults if arguments are not present
if nargin<4|isempty(es), es=0.0001;,end
if nargin<5|isempty(maxit),maxit=50;,end
%initialize xr and iter to starting values
iter = 0;
while(1)
        xrold = xr;
        xr = xr-func(xr,varargin{:})*(deltaxr)/(func(xr+deltaxr,varargin{:})-func(xr,varargin{:}));
        iter = iter + 1;
        if xr ~= 0
            ea = abs((xr-xrold)/xr)*100;
        end
        if (ea<=es | iter >= maxit)
            break
        end
end
root = xr;
end