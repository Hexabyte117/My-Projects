%Elijah Goodrich
clc
clear all
%part a
syms t
d=7.45*sin(2*t)*(1+(1+(0.41/(sin(t))^2))^.5);
a0=fplot(d,[0,pi/2]);
legend([a0],'t');
xlabel('Radians');
ylabel('Distance');
%% Part b 
der=diff(d);
dd=double(solve(der,t));
launchangle=dd(1,1)
dist=double(subs(d,t,dd));
distance=dist(1,1)
%% Part c
xu=90;
xl=0;
phi = (1+sqrt(5))/2;
iter = 0;
es=0.001;
f=@(t) 7.45.*sin(2.*t).*(1+(1+(0.41./(sin(t)).^2)).^.5); 
while(1)
    di = (phi-1)*(xu-xl);
    x1 = xl+di;
    x2 = xu-di;
    if (-f(x1) < -f(x2))
        xopt(iter+1,1) = x1;
        xl=x2;
    else
        xopt(iter+1,1)=x2;
        xu=x1;
    end
    
    iter = iter+1;
    
    if xopt(iter,1)~=0,ea=(2-phi)*abs((xu-xl)/xopt(iter,1))*100;end
    if ea<=es,break,end
end
x=xopt(end,1);
fx=f(x)
interations=iter
%% Part d
x1=0.001;
x3=pi/2;
es=0.001;
maxit=50;
f=@(t) -7.45.*sin(2.*t).*(1+(1+(0.41./(sin(t)).^2)).^.5);
iter = 0;
%Find the value for the midpoint guess
x2=(x1+x3)/2;
%Check to see if a minimum is bracketed by the two guesses
if (f(x2)>f(x3) | f(x2)>f(x1))
    error('no minimum exists between roots')
end
%While loop that runs until cutoff criteria are met  
xoptd=x2;
while(1)
	%Holds the old value of x2
    x2old = x2;
	%Parabolic interpolation formula
    x4 = x2-1/2*(((x2-x1)^2*(f(x2)-f(x3))-(x2-x3)^2*(f(x2)-f(x1)))/((x2-x1)*(f(x2)-f(x3))-(x2-x3)*(f(x2)-f(x1))));
    %Check to see if the right or left endpoint should be replaced
	if (x4 >x2)
		if (f(x4) < f(x2))
        		x1=x2;
			x2=x4;
    		else
        		x3=x4;
   	 	end
	else
		if (f(x4) < f(x2))
			x3=x2;
			x2=x4;
		else
			x1=x4;
		end
	end
		%increment the number of iterations
    	iter = iter+1;
		%Calculate the approximate error
    	ea = abs((x2-x2old)/x2)*100;
        xoptd(iter+1,1)=x2;
	%Check to see if it has reached the maximum number of iterations or if it is less than the stopping criteria
    if ea<=es | iter>=maxit,break,end
  
end
%give the root
x=x4;
%give the value of the minima
fx=-f(x2)
interationspara=iter
%% Part e
daabs=zeros(length(xoptd),1);
Doptd=-f(xoptd);
for i=1:length(xoptd)
    daabs(i,1)=(dist(1,1)-Doptd(i,1))/dist(1,1);
    aproxerr(i,1)=(dist(1,1)-Doptd(i,1));
end
%from part c
daabs
aproxerr
plot(daabs)
hold on
plot(aproxerr)
%from part d
daabs2=zeros(length(xoptd),1);
Doptd=-f(xoptd);
for i=1:length(xoptd)
    daabs2(i,1)=(dist(1,1)-Doptd(i,1))/dist(1,1);
    aproxerr(i,1)=(dist(1,1)-Doptd(i,1));
end