%Elijah Goodrich
clc
clear all
%part a
C = [0.5; 0.8; 1.5; 2.5; 4]
K = [1.1; 2.5; 5.3; 7.6; 8.9]
scatter(C,K)
title('Bacterial Growth Data')
xlabel('Concentrations')
ylabel('Growth Rate K')
%% Part B
mxb = polyfit(1./C.^2,1./K,1);
m = mxb(1);
Kmax = 1/mxb(2);
Cs = m*Kmax;
%% Part C
[a f] = fminsearch(@FSSR, [4 4], [], C , K);
Kmax = a(1);
Cs1 = a(2);
%% Part D
c=1
k1=(10.3449*c)/(1.4025+c^2)
k2=(10.3449*c)/(2.0897+c^2)