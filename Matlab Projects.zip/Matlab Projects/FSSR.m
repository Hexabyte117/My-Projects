function [Fval] = FSSR(a, x, y)
yp = a(1).*x.^2./(a(2).^2+x.^2);
Fval = sum((y-yp).^2);
end