%Elijah Goodrich
%% part c
daabs=-(1.9020-1.9021)/1.9020
    aproxerr=-(1.9020-1.9021)
   daabsfalsepos=(1.9080-1.9021)/1.9080
    aproxerrfalsepos=(1.9080-1.9021) 
 