DC1dx = 1.2;
DC2dx = -0.2;
L = 150;
D=0.85;
dx= 0.5;
x = [0:dx:L];
dt = 0.05;
t = [0:dt:5000];
C = zeros(length(t),length(x));
C(:,:)=250;

for i = 1:length(t)-1
    for j = 1:length(x)-1
        if j == 1
            CN = C(i,j+1) - 2*dx*DC1dx*C(i,j);
            C(i+1,j) = dt*D*(CN-2*C(i,j)+C(i,j+1))/(dx^2)+C(i,j);
        elseif j==length(x)-1;
            CN = C(i,j-1) + 2*dx*DC2dx*C(i,j);
            C(i+1,j) = dt*D*(C(i,j-1)-2*C(i,j)+CN)/(dx^2)+C(i,j);
        else
            C(i+1,j) = dt*D*(C(i,j-1)-2*C(i,j)+C(i,j+1))/(dx^2)+C(i,j);
        end
    end
end

figure()
hold on
a0=plot(x,C(1,:));
a1=plot(x,C(5/dt+1,:));
a2=plot(x,C(10/dt+1,:));
a3=plot(x,C(20/dt+1,:));
a4=plot(x,C(40/dt+1,:));
a5=plot(x,C(60/dt+1,:));
a6=plot(x,C(120/dt+1,:));
a7=plot(x,C(1200/dt+1,:));
a8=plot(x,C(5000/dt+1,:));
legend([a0; a1; a2; a3; a4; a5; a6; a7; a8],'t=0','t=5','t=10','t=20','t=40','t=60','t=120','t=1200','t=5000');
xlabel('distance (um)')
ylabel('Concentration (ug/ml)')
hold off

