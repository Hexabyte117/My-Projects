%Elijah Goodrich
clc
clear all
%part a
N= 64;
dt = 0.01;
fs =1/dt;
T=dt*N;
t = (0:N-1)/fs;
y = cos(2*pi*12*t) + sin(2*pi*24*t);
fmax=fs/2;
fmin =1/T;
f=linspace(fmin,fmax,N/2)
yp=fft(y)/N;
P2 = abs(yp/N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1);
fx = fs*(0:(N/2))/N;
plot(fx,P1)
%% Part b
N= 64;
dt = 0.05;
fs =1/dt;
T=dt*N;
t = (0:N-1)/fs;
y = cos(2*pi*12*t) + sin(2*pi*24*t);
fmax=fs/2;
fmin =1/T;
f=linspace(fmin,fmax,N/2)
yp=fft(y)/N;
P2 = abs(yp/N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1);
fx = fs*(0:(N/2))/N;
plot(fx,P1)
%The values differed slightly not noticable 